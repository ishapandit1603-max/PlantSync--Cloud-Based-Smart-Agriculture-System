#!/usr/bin/env bash
# Run this in AWS CloudShell (browser terminal, nothing to install on your PC).
#   bash setup_aws.sh
# Creates: DynamoDB table, S3 bucket, IoT Core thing+certificate+policy, Lambda + IoT Rule, EC2 IAM role.
set -euo pipefail
REGION="${AWS_REGION:-ap-south-1}"
export AWS_DEFAULT_REGION="$REGION"
ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
TABLE=PlantSyncState
BUCKET="plantsync-data-$ACCOUNT"
mkdir -p certs

echo "==> DynamoDB (provisioned 5/5 = always-free tier)"
aws dynamodb create-table --table-name $TABLE \
  --attribute-definitions AttributeName=pk,AttributeType=S AttributeName=sk,AttributeType=S \
  --key-schema AttributeName=pk,KeyType=HASH AttributeName=sk,KeyType=RANGE \
  --billing-mode PROVISIONED --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 >/dev/null
aws dynamodb wait table-exists --table-name $TABLE
aws dynamodb update-time-to-live --table-name $TABLE --time-to-live-specification Enabled=true,AttributeName=ttl >/dev/null

echo "==> S3 bucket $BUCKET"
if [ "$REGION" = "us-east-1" ]; then aws s3api create-bucket --bucket $BUCKET >/dev/null
else aws s3api create-bucket --bucket $BUCKET --create-bucket-configuration LocationConstraint=$REGION >/dev/null; fi
aws s3api put-public-access-block --bucket $BUCKET --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true

echo "==> IoT Core thing, certificate, policy"
aws iot create-policy --policy-name PlantSyncPolicy --policy-document file://iot_policy.json >/dev/null
aws iot create-thing --thing-name plantsync-gateway >/dev/null
CERT_ARN=$(aws iot create-keys-and-certificate --set-as-active \
  --certificate-pem-outfile certs/device.pem.crt --public-key-outfile certs/public.key \
  --private-key-outfile certs/private.pem.key --query certificateArn --output text)
aws iot attach-policy --policy-name PlantSyncPolicy --target "$CERT_ARN"
aws iot attach-thing-principal --thing-name plantsync-gateway --principal "$CERT_ARN"
curl -s https://www.amazontrust.com/repository/AmazonRootCA1.pem -o certs/AmazonRootCA1.pem
ENDPOINT=$(aws iot describe-endpoint --endpoint-type iot:Data-ATS --query endpointAddress --output text)

echo "==> Lambda (validation/routing) + IoT Rule"
cat > /tmp/trust_lambda.json <<J
{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"lambda.amazonaws.com"},"Action":"sts:AssumeRole"}]}
J
aws iam create-role --role-name PlantSyncLambdaRole --assume-role-policy-document file:///tmp/trust_lambda.json >/dev/null
aws iam attach-role-policy --role-name PlantSyncLambdaRole --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole
cat > /tmp/lambda_ddb.json <<J
{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":"dynamodb:PutItem","Resource":"arn:aws:dynamodb:$REGION:$ACCOUNT:table/$TABLE"}]}
J
aws iam put-role-policy --role-name PlantSyncLambdaRole --policy-name ddb --policy-document file:///tmp/lambda_ddb.json
sleep 12
(cd lambda && zip -q ../lambda.zip handler.py)
LAMBDA_ARN=$(aws lambda create-function --function-name plantsync-ingest --runtime python3.12 \
  --handler handler.lambda_handler --role arn:aws:iam::$ACCOUNT:role/PlantSyncLambdaRole \
  --zip-file fileb://lambda.zip --timeout 10 --environment "Variables={TABLE=$TABLE}" \
  --query FunctionArn --output text)
cat > /tmp/rule.json <<J
{"sql":"SELECT * FROM 'plantsync/+/telemetry'","ruleDisabled":false,"awsIotSqlVersion":"2016-03-23","actions":[{"lambda":{"functionArn":"$LAMBDA_ARN"}}]}
J
aws iot create-topic-rule --rule-name plantsync_ingest --topic-rule-payload file:///tmp/rule.json
aws lambda add-permission --function-name plantsync-ingest --statement-id iot-invoke \
  --action lambda:InvokeFunction --principal iot.amazonaws.com \
  --source-arn arn:aws:iot:$REGION:$ACCOUNT:rule/plantsync_ingest >/dev/null

echo "==> EC2 instance role (DynamoDB events + S3 snapshots only)"
cat > /tmp/trust_ec2.json <<J
{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"ec2.amazonaws.com"},"Action":"sts:AssumeRole"}]}
J
aws iam create-role --role-name PlantSyncEC2Role --assume-role-policy-document file:///tmp/trust_ec2.json >/dev/null
cat > /tmp/ec2_policy.json <<J
{"Version":"2012-10-17","Statement":[
 {"Effect":"Allow","Action":["dynamodb:PutItem","dynamodb:Query"],"Resource":"arn:aws:dynamodb:$REGION:$ACCOUNT:table/$TABLE"},
 {"Effect":"Allow","Action":["s3:PutObject","s3:GetObject"],"Resource":"arn:aws:s3:::$BUCKET/*"}]}
J
aws iam put-role-policy --role-name PlantSyncEC2Role --policy-name plantsync --policy-document file:///tmp/ec2_policy.json
aws iam create-instance-profile --instance-profile-name PlantSyncEC2Profile >/dev/null
aws iam add-role-to-instance-profile --instance-profile-name PlantSyncEC2Profile --role-name PlantSyncEC2Role

cat <<OUT

================ DONE ================
Put these in your .env on the EC2 server:
  AWS_REGION=$REGION
  IOT_ENDPOINT=$ENDPOINT
  S3_BUCKET=$BUCKET
  DDB_TABLE=$TABLE
Download the 3 files in ./certs  (CloudShell: Actions > Download file):
  device.pem.crt, private.pem.key, AmazonRootCA1.pem
Then continue with README step 3 (launch EC2).
OUT
