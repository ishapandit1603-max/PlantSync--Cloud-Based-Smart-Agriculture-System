"""AWS Lambda (IoT Rule target): validates telemetry and routes it to DynamoDB with a 7-day TTL."""
import json, os, time
from decimal import Decimal
import boto3

table = boto3.resource("dynamodb").Table(os.environ["TABLE"])
LIMITS = {"soil_moisture": (0, 100), "temperature": (-20, 70), "humidity": (0, 100), "ph": (0, 14)}


def lambda_handler(event, context):
    flags = [k for k, (lo, hi) in LIMITS.items() if event.get(k) is None or not lo <= event[k] <= hi]
    item = {**event, "pk": f"TEL#{event['device_id']}", "sk": event["ts"], "suspect": flags,
            "ttl": int(time.time()) + 7 * 86400}
    table.put_item(Item=json.loads(json.dumps(item), parse_float=Decimal))
    return {"stored": True, "suspect": flags}
