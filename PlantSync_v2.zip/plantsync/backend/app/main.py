import logging, threading, time
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from . import config as C, copilot, ml
from .engine import Engine
from .virtual_esp32 import VirtualESP32

logging.basicConfig(level=logging.INFO)
engine = Engine()


def run_embedded(sims):
    while True:
        for s in sims.values():
            engine.ingest(s.tick())
        time.sleep(C.SIM_INTERVAL)


@asynccontextmanager
async def lifespan(app):
    if C.MQTT_ENABLED:
        from .mqtt_client import MqttBridge
        bridge = MqttBridge(engine)
        bridge.start()
        engine.publisher, engine.mode = bridge.publish_command, "AWS IoT Core · MQTT"
    else:
        sims = {d: VirtualESP32(d, C.CSV_PATH) for d in C.DEVICES}
        engine.publisher, engine.mode = (lambda d, cmd: sims[d].apply_command(cmd)), "Embedded demo (no AWS)"
        threading.Thread(target=run_embedded, args=(sims,), daemon=True).start()
    yield


app = FastAPI(title="PlantSync", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.exception_handler(Exception)
async def boom(request: Request, exc: Exception):
    logging.exception("unhandled error on %s", request.url.path)
    return JSONResponse({"detail": f"{type(exc).__name__}: {exc}"}, status_code=500)


class ActuatorIn(BaseModel):
    device: str
    actuator: str
    state: bool
    seconds: int = 0


class AutoIn(BaseModel):
    enabled: bool


class ResumeIn(BaseModel):
    device: str | None = None
    actuator: str | None = None


class InjectIn(BaseModel):
    device: str
    kind: str


class ChatIn(BaseModel):
    message: str
    history: list[dict] = []


class WhatIfIn(BaseModel):
    moisture: float = 0
    temperature: float = 0
    nitrogen: float = 0
    ph: float = 0


@app.get("/api/health")
def health():
    return {"status": "ok", "mode": engine.mode, "messages": engine.msgs}


@app.get("/api/snapshot")
def snapshot():
    return engine.snapshot()


@app.post("/api/actuator")
def actuator(b: ActuatorIn):
    ok = engine.command(b.device, b.actuator, b.state, "manual control from dashboard", "Operator", min(max(b.seconds, 0), 600))
    return {"ok": ok}


@app.post("/api/stop_all")
def stop_all():
    return {"ok": engine.stop_all("Operator")}


@app.post("/api/resume")
def resume(b: ResumeIn):
    return {"ok": engine.resume_auto(b.device, b.actuator)}


@app.post("/api/auto")
def auto(b: AutoIn):
    if b.enabled:
        engine.resume_auto()
    else:
        engine.auto = False
        engine.log("Irrigation Agent", "ok", "Automatic control disabled (manual mode)")
    return {"auto": engine.auto}


@app.post("/api/inject")
def inject(b: InjectIn):
    return {"ok": engine.inject(b.device, b.kind)}


@app.get("/api/snapshots")
def snapshots():
    return {"cloud": engine.store.cloud_status(), "every": C.SNAPSHOT_EVERY, **engine.store.list_snapshots()}


@app.post("/api/snapshots/now")
def snapshot_now():
    return engine.save_snapshot("manual")


@app.post("/api/chat")
def chat(b: ChatIn):
    return copilot.ask(engine, b.message, b.history)


@app.get("/api/llm/status")
def llm_status():
    return copilot.check()


@app.post("/api/whatif")
def whatif(b: WhatIfIn):
    base = engine.average()
    if not base:
        return {"scenarios": []}
    presets = [("Baseline", {}), ("Your scenario", {"soil_moisture": b.moisture, "temperature": b.temperature, "nitrogen": b.nitrogen, "ph": b.ph}),
               ("Irrigate +15%", {"soil_moisture": 15}), ("Heatwave +5°C", {"temperature": 5}),
               ("Add nitrogen +20", {"nitrogen": 20}), ("Drought -20%", {"soil_moisture": -20})]
    out = []
    for name, delta in presets:
        r = dict(base)
        for k, v in delta.items():
            r[k] += v
        out.append({"name": name, **ml.predict(r)})
    return {"scenarios": out}


STATIC = Path(__file__).resolve().parent.parent / "static"
if (STATIC / "assets").exists():
    app.mount("/assets", StaticFiles(directory=STATIC / "assets"), name="assets")

    @app.get("/{path:path}")
    def spa(path: str):
        f = (STATIC / path).resolve()
        return FileResponse(f if f.is_file() and STATIC.resolve() in f.parents else STATIC / "index.html")
