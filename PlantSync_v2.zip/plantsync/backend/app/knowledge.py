"""Knowledge Agent: tiny agronomy knowledge base with keyword retrieval (swap for a vector DB later)."""
import re

KB = [
 ("Soil moisture targets", "Most vegetables and maize perform best at 45-65% volumetric soil moisture. Below 30% plants wilt; above 75% roots suffocate. Irrigate in short cycles early morning."),
 ("Soil pH management", "Ideal pH is 6.0-7.0 for tomato and maize. Low pH (<5.5) locks phosphorus and needs lime; high pH (>7.5) reduces iron and zinc uptake and can be corrected with sulphur or organic matter."),
 ("Nitrogen deficiency", "Pale lower leaves and slow growth indicate nitrogen deficiency. Apply split doses of urea or compost tea. Keep soil nitrogen above 45 mg/kg during vegetative growth."),
 ("Heat stress", "Above 34 C tomato flowers drop and maize pollination fails. Use shade nets, ventilation or cooling fans, irrigate in the evening, and avoid fertilising during heat waves."),
 ("Humidity and disease", "Humidity above 85% with warm nights favours blight and powdery mildew. Improve airflow, avoid overhead watering, and scout leaves for spots."),
 ("Sensor faults", "Capacitive soil moisture probes can freeze at one value when wiring loosens or corrodes. Dropouts usually mean a loose I2C/analog connection. Reboot the node, reseat the probe, then recalibrate."),
 ("Potassium and phosphorus", "Potassium of 120-200 mg/kg supports fruit quality; phosphorus of 25-45 mg/kg supports roots. Deficiencies show as leaf-edge burn (K) or purple leaves (P)."),
 ("Sunlight", "Tomato and maize need 500-800 W/m2 midday light. Prolonged low light slows growth and increases disease; excessive light plus heat causes sunscald."),
 ("Irrigation scheduling", "Drip irrigation at about 8 L/min per bed restores 20-25% moisture in 10 minutes. Skip irrigation when rainfall exceeds 1 mm/h."),
]
_tok = lambda s: set(re.findall(r"[a-z0-9]+", s.lower()))


def search(query, k=2):
    q = _tok(query)
    scored = sorted(((len(q & _tok(t + " " + x)), t, x) for t, x in KB), reverse=True)
    return [{"title": t, "text": x} for s, t, x in scored[:k] if s > 0]
