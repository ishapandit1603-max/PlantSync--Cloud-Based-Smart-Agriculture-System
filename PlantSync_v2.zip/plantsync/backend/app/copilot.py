"""Farm Copilot: Llama (or the best live model) via Groq + local command handling + Knowledge Agent retrieval.
Works in three layers: 1) local commands ("stop the pump in field A") need no LLM, 2) Groq chat with tool calling,
3) a clean written status summary if Groq is unreachable. Real error reasons are returned to the UI."""
import json, logging, re, time
import httpx
from . import config as C, knowledge
from .engine import ACT, ACT_LABEL

log = logging.getLogger("copilot")
API = "https://api.groq.com/openai/v1"
PREFER = [r"llama-4", r"llama-3\.3-70b", r"llama-3\.1-8b", r"gpt-oss-120b", r"gpt-oss-20b", r"qwen"]
SKIP = ("guard", "whisper", "tts", "orpheus", "embed", "compound", "safeguard", "distil", "vision", "saba")
_models = {"t": 0.0, "list": []}

TOOLS = [{"type": "function", "function": {
    "name": "set_actuator", "description": "Turn a virtual farm actuator ON or OFF",
    "parameters": {"type": "object", "properties": {
        "device": {"type": "string", "enum": C.DEVICES},
        "actuator": {"type": "string", "enum": ACT},
        "state": {"type": "string", "enum": ["ON", "OFF"]}}, "required": ["device", "actuator", "state"]}}}]

SYSTEM = ("You are PlantSync Farm Copilot, a friendly agronomy assistant for a two-field smart farm (Field A tomato, Field B maize). "
          "Answer in plain English in at most 5 short sentences, or a short list using '-' bullets. No tables, no code blocks, no headings, "
          "no emojis. Use units (%, °C, mg/kg). Mention only the readings that matter for the question and never invent numbers: "
          "use only the LIVE STATE and KNOWLEDGE below. If the farm is fine, say so briefly. Call set_actuator only when the user asks you to switch something.")


class GroqError(Exception):
    def __init__(self, kind, detail, status=None):
        super().__init__(detail)
        self.kind, self.detail, self.status = kind, detail, status


# ---------- live state ----------
def _zones(engine):
    return list(engine.snapshot()["devices"].values())


def context(engine):
    snap, out = engine.snapshot(), []
    for v in snap["devices"].values():
        r = v["latest"]
        if r:
            on = [ACT_LABEL[a] for a, s in v["actuators"].items() if s] or ["none"]
            out.append(f"{v['zone']}: moisture {r['soil_moisture']}%, temp {r['temperature']}C, humidity {r['humidity']}%, pH {r['ph']}, "
                       f"N {r['nitrogen']} P {r['phosphorus']} K {r['potassium']} mg/kg, sunlight {r['sunlight']} W/m2, "
                       f"crop health {r['health']}%, yield {r['yield']} t/ha, running now: {', '.join(on)}, sensors {v['health']['status']}")
    w = snap["water"]
    out.append(f"Water used {w['used_l']} L, saved {w['saved_l']} L ({w['saved_pct']:.0f}%) versus fixed-timer irrigation.")
    out.append("Recent anomalies: " + ("; ".join(f"{a['zone']} {a['kind'].replace('_', ' ')} on {a['field']}" for a in snap["anomalies"][:4]) or "none"))
    out.append("Auto control: " + ("on" if snap["auto"] else "off"))
    return "\n".join(out)


def summary_text(engine):
    snap, lines = engine.snapshot(), []
    for v in snap["devices"].values():
        r = v["latest"]
        if r:
            on = [ACT_LABEL[a] for a, s in v["actuators"].items() if s]
            lines.append(f"- {v['zone']}: crop health {r['health']:.0f}%, soil moisture {r['soil_moisture']:.0f}%, {r['temperature']:.1f}°C, "
                         f"pH {r['ph']:.2f}. Running: {', '.join(on) if on else 'nothing'}. Sensors {v['health']['status']}.")
    w = snap["water"]
    lines.append(f"- Water saved so far: {w['saved_l']} L ({w['saved_pct']:.0f}%) compared with fixed-timer irrigation.")
    return "\n".join(lines)


# ---------- local commands (no LLM needed) ----------
QUESTION = {"should", "why", "how", "is", "what", "can", "does", "do", "when", "are", "will", "which", "who", "tell", "explain"}
ACTWORD = {"irrigation_pump": r"pump|irrigat|water|drip", "fertilizer_doser": r"fertili[sz]|doser|dosing|nutrient",
           "cooling_fan": r"fan|cooling|cool|ventilat"}


def local_command(engine, message):
    t = re.sub(r"[^a-z0-9 ]", " ", message.lower()).split()
    text = " ".join(t)
    if not t or t[0] in QUESTION or len(t) > 16:
        return None
    off = re.search(r"\b(stop|off|disable|deactivate|shut|halt|kill)\b", text)
    on = re.search(r"\b(start|on|run|enable|activate|begin|open)\b", text)
    if not (on or off):
        return None
    state = not off
    if re.search(r"\b(everything|all|emergency)\b", text) and off:
        engine.stop_all("Farm Copilot")
        return "Emergency stop done: every pump, fan and doser is OFF. Automatic control is paused for 5 minutes.", ["All actuators OFF"]
    acts = [a for a, p in ACTWORD.items() if re.search(p, text)]
    if not acts:
        return None
    devs = [d for d, pat in (("esp32-field-a", r"\b(field a|zone a|a field|tomato)\b"), ("esp32-field-b", r"\b(field b|zone b|b field|maize|corn)\b")) if re.search(pat, text)] or list(C.DEVICES)
    done = []
    for d in devs:
        for a in acts:
            if engine.command(d, a, state, "requested via Farm Copilot", "Farm Copilot"):
                done.append(f"{ACT_LABEL[a]} {'ON' if state else 'OFF'} · {C.ZONES[d]}")
    names = ", ".join(sorted({x.split(' · ')[1] for x in done}))
    return (f"Done. {', '.join(sorted({ACT_LABEL[a] for a in acts}))} turned {'ON' if state else 'OFF'} for {names}. "
            f"Automatic control is paused for {C.HOLD_SECONDS} seconds for those actuators."), done


# ---------- Groq ----------
def _headers():
    return {"Authorization": f"Bearer {C.GROQ_API_KEY}"}


def live_models():
    if time.time() - _models["t"] < 600 and _models["list"]:
        return _models["list"]
    try:
        r = httpx.get(f"{API}/models", headers=_headers(), timeout=15)
        r.raise_for_status()
        ids = [m["id"] for m in r.json().get("data", []) if m.get("active", True) and not any(s in m["id"].lower() for s in SKIP)]
        rank = lambda i: next((n for n, p in enumerate(PREFER) if re.search(p, i)), len(PREFER))
        _models.update(t=time.time(), list=sorted(ids, key=rank))
    except Exception as ex:
        log.warning("model discovery failed: %s", ex)
    return _models["list"]


def _call(model, messages, tools):
    body = {"model": model, "messages": messages, "temperature": 0.3, "max_tokens": 1000}
    if model.startswith("openai/gpt-oss"):
        body["reasoning_effort"] = "low"
    if tools:
        body.update(tools=tools, tool_choice="auto")
    try:
        r = httpx.post(f"{API}/chat/completions", json=body, headers=_headers(), timeout=30)
    except httpx.TimeoutException:
        raise GroqError("timeout", "Groq took too long to answer")
    except httpx.HTTPError as ex:
        raise GroqError("network", f"could not connect to api.groq.com ({type(ex).__name__})")
    if r.status_code != 200:
        try:
            err = r.json().get("error", {})
        except Exception:
            err = {}
        msg, code = err.get("message", r.text[:200]), str(err.get("code", ""))
        low = (msg + code).lower()
        kind = ("auth" if r.status_code in (401, 403) else "rate" if r.status_code == 429 else
                "tool" if "tool" in low else "model" if ("model" in low or r.status_code == 404) else "http")
        raise GroqError(kind, msg, r.status_code)
    return r.json()["choices"][0]["message"]


def chat(messages, tools=None):
    """Try the configured model, then every live model in preference order. Returns (message, model)."""
    order = [] if C.GROQ_MODEL == "auto" else [C.GROQ_MODEL]
    last = None
    for model in order + [m for m in live_models() if m not in order][:4]:
        use_tools = tools
        for _ in range(2):
            try:
                m = _call(model, messages, use_tools)
                if m.get("tool_calls") or (m.get("content") or "").strip():
                    return m, model
                last = GroqError("empty", f"{model} returned an empty answer")
                break
            except GroqError as e:
                last = e
                if e.kind == "tool" and use_tools:
                    use_tools = None          # retry same model without tools
                    continue
                break
        if last and last.kind in ("auth", "rate", "network", "timeout"):
            raise last
    raise last or GroqError("model", "no usable Groq model was found for this API key")


def clean(text):
    text = re.sub(r"<think>.*?</think>", "", text or "", flags=re.S)
    text = re.sub(r"^\s*(assistant|copilot)\s*:\s*", "", text.strip(), flags=re.I)
    text = re.sub(r"[ \t]+\n", "\n", text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def friendly(e):
    return {"auth": "Groq rejected the API key. Check GROQ_API_KEY in .env, then run: docker compose up -d",
            "rate": "Groq's free rate limit was reached. Wait a few seconds and ask again.",
            "network": "The server could not reach api.groq.com. Check the instance's internet access.",
            "timeout": "Groq took too long to respond. Please try again.",
            "model": "No active Groq model accepted the request (models get retired often). Set GROQ_MODEL=auto in .env.",
            }.get(e.kind, f"Groq returned an error: {e.detail[:160]}")


def check():
    if not C.GROQ_API_KEY:
        return {"configured": False, "ok": False, "model": None, "detail": "GROQ_API_KEY is empty in .env"}
    try:
        m, model = chat([{"role": "user", "content": "Reply with the single word OK."}])
        return {"configured": True, "ok": True, "model": model, "detail": "Groq is reachable"}
    except GroqError as e:
        return {"configured": True, "ok": False, "model": None, "detail": friendly(e), "raw": e.detail[:300], "models": live_models()[:6]}


# ---------- main entry ----------
def ask(engine, message, history):
    message = message.strip()[:600]
    cmd = local_command(engine, message)
    if cmd:
        engine.stat("Farm Copilot", message[:60])
        return {"reply": cmd[0], "sources": [], "actions": cmd[1], "model": "local control", "error": None}
    docs = knowledge.search(message + " " + " ".join(f"{a['field']} {a['kind']}" for a in list(engine.anomalies)[-2:]))
    engine.stat("Knowledge Agent", f"retrieved {len(docs)} guidance notes")
    sources, actions = [d["title"] for d in docs], []
    if not C.GROQ_API_KEY:
        return {"reply": "The Llama assistant is not configured yet (no GROQ_API_KEY). Here is the live farm status:\n" + summary_text(engine),
                "sources": sources, "actions": [], "model": None,
                "error": {"kind": "config", "detail": "Add GROQ_API_KEY to .env and run: docker compose up -d"}}
    system = SYSTEM + "\n\nLIVE STATE:\n" + context(engine) + "\n\nKNOWLEDGE:\n" + "\n".join(f"- {d['title']}: {d['text']}" for d in docs)
    hist = [{"role": h["role"], "content": str(h["content"])[:800]} for h in history[-6:] if h.get("role") in ("user", "assistant") and h.get("content")]
    msgs = [{"role": "system", "content": system}] + hist + [{"role": "user", "content": message}]
    wants_action = re.search(r"\b(turn|switch|start|stop|run|enable|disable|shut|activate|irrigate|cool|dose|fertili[sz]e)\b", message.lower())
    try:
        m, model = chat(msgs, TOOLS if wants_action else None)
        if m.get("tool_calls"):
            calls = [{"id": tc["id"], "type": "function", "function": {"name": tc["function"]["name"], "arguments": tc["function"]["arguments"]}} for tc in m["tool_calls"]]
            msgs.append({"role": "assistant", "content": m.get("content") or "", "tool_calls": calls})
            for tc in calls:
                try:
                    a = json.loads(tc["function"]["arguments"])
                    ok = tc["function"]["name"] == "set_actuator" and engine.command(a.get("device"), a.get("actuator"), a.get("state") == "ON", "requested via Farm Copilot", "Farm Copilot")
                except Exception:
                    a, ok = {}, False
                if ok:
                    actions.append(f"{ACT_LABEL.get(a.get('actuator'), a.get('actuator'))} {a.get('state')} · {C.ZONES.get(a.get('device'), a.get('device'))}")
                msgs.append({"role": "tool", "tool_call_id": tc["id"], "content": json.dumps({"ok": bool(ok)})})
            try:
                m, model = chat(msgs)
                reply = clean(m.get("content"))
            except GroqError:
                reply = "Done: " + "; ".join(actions) if actions else "I could not complete that action."
        else:
            reply = clean(m.get("content"))
        engine.stat("Farm Copilot", message[:60])
        return {"reply": reply or "I'm not sure about that. Could you rephrase?", "sources": sources, "actions": actions, "model": model, "error": None}
    except GroqError as e:
        log.warning("Groq failed: %s %s", e.kind, e.detail)
        return {"reply": "I could not reach the Llama service just now, but here is the live farm status:\n" + summary_text(engine),
                "sources": sources, "actions": actions, "model": None, "error": {"kind": e.kind, "detail": friendly(e), "raw": e.detail[:300]}}
