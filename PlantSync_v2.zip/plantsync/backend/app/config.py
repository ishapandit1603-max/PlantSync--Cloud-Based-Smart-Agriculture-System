import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
E = lambda k, d="": os.getenv(k, d)

MQTT_ENABLED = E("MQTT_ENABLED", "true").lower() == "true"   # false = embedded demo (no AWS)
IOT_ENDPOINT = E("IOT_ENDPOINT").strip()
CERT_DIR = E("CERT_DIR", "/certs")
AWS_REGION = E("AWS_REGION", "ap-southeast-2").strip()
DDB_TABLE = E("DDB_TABLE", "PlantSyncState").strip()
S3_BUCKET = E("S3_BUCKET").strip()
USE_AWS = E("USE_AWS_STORAGE", "true" if MQTT_ENABLED else "false").lower() == "true"

# --- Groq / Llama ---  GROQ_MODEL=auto  -> picks a live model from Groq's /models list (Llama preferred)
GROQ_API_KEY = E("GROQ_API_KEY").strip().strip("'\"")
GROQ_MODEL = E("GROQ_MODEL", "auto").strip()

# --- simulation / control ---
SIM_INTERVAL = float(E("SIM_INTERVAL", "3"))          # seconds between readings per virtual ESP32
DEMO_FAST = E("DEMO_FAST", "true").lower() == "true"  # fast field physics so auto-switching is visible (~30-60 s cycles)
HOLD_SECONDS = int(E("HOLD_SECONDS", "90"))           # auto control pauses this long after a manual action
SNAPSHOT_EVERY = int(E("SNAPSHOT_EVERY", "120"))      # seconds between farm snapshots (DynamoDB + S3)
PUMP_LPM = 8.0                                        # litres/min of one drip line
BASELINE_DUTY = float(E("BASELINE_DUTY", "0.6"))      # assumed duty cycle of a fixed-timer irrigation system

DEVICES = ["esp32-field-a", "esp32-field-b"]
ZONES = {"esp32-field-a": "Field A · Tomato", "esp32-field-b": "Field B · Maize"}
CSV_PATH = E("CSV_PATH", str(Path(__file__).resolve().parent.parent / "data" / "farm_data.csv"))
TOPIC_T = "plantsync/{}/telemetry"
TOPIC_C = "plantsync/{}/commands"
