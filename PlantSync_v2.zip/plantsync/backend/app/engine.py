"""Orchestrator + agents: Telemetry -> Anomaly -> Self-Healing -> Irrigation/Control -> Prediction."""
import collections, statistics, threading, time
from . import config as C, ml
from .store import Store
from .virtual_esp32 import now

RANGES = {"soil_moisture": (0, 100), "temperature": (-5, 50), "humidity": (0, 100), "ph": (3, 10),
          "nitrogen": (0, 200), "phosphorus": (0, 150), "potassium": (0, 400), "sunlight": (0, 1400), "rainfall": (0, 100)}
JUMP = {"soil_moisture": 45, "temperature": 9, "humidity": 30, "ph": 1.2, "nitrogen": 40, "phosphorus": 30, "potassium": 80}
STUCK = ["soil_moisture", "temperature", "humidity", "ph"]
MOIST_ON, MOIST_OFF, FAN_ON, FAN_OFF, N_ON, N_OFF = 35, 55, 34, 30, 45, 65
AGENTS = {
    "Telemetry Agent": "Validates ESP32 packets from MQTT and saves farm snapshots to the cloud.",
    "Anomaly Agent": "Detects dropouts, spikes, out-of-range and stuck sensors.",
    "Self-Healing Agent": "Detect, diagnose, act, verify: repairs data and reboots faulty nodes.",
    "Irrigation Agent": "Closed-loop control of pump, fertiliser doser and cooling fan.",
    "Prediction Agent": "Random Forest model for crop health and yield.",
    "Knowledge Agent": "Retrieves agronomy guidance for diagnoses and answers.",
    "Farm Copilot": "Llama assistant (via Groq) that can read the farm and actuate it.",
}
ACT = ["irrigation_pump", "fertilizer_doser", "cooling_fan"]
ACT_LABEL = {"irrigation_pump": "Irrigation pump", "fertilizer_doser": "Fertiliser doser", "cooling_fan": "Cooling fan"}
MANUAL = {"Operator", "Farm Copilot"}          # sources that pause the automatic controller
FAULTS = {"stuck", "spike", "dropout", "outofrange"}


class Engine:
    def __init__(self):
        self.lock = threading.RLock()
        D = C.DEVICES
        self.history = {d: collections.deque(maxlen=240) for d in D}
        self.rawtail = {d: collections.deque(maxlen=10) for d in D}
        self.latest, self.pred = {}, {}
        self.events = collections.deque(maxlen=150)
        self.anomalies = collections.deque(maxlen=60)
        self.active = {d: set() for d in D}
        self.seen = {d: set() for d in D}
        self.health = {d: {"status": "healthy", "clean": 0, "faults": 0} for d in D}
        self.actuators = {d: {a: False for a in ACT} for d in D}
        self.hold = {d: {a: 0.0 for a in ACT} for d in D}           # epoch until which auto control is paused
        self.water = {d: {"used": 0.0, "baseline": 0.0, "run_s": 0.0} for d in D}
        self._last_t = {d: None for d in D}
        self.water_series = collections.deque(maxlen=90)
        self._series_t = 0.0
        self.stats = {a: {"runs": 0, "last": "idle", "ts": None} for a in AGENTS}
        self.auto, self.msgs, self.mode, self.publisher = True, 0, "starting", None
        self.store = Store()
        self._snap_t = time.time() - C.SNAPSHOT_EVERY + 20           # first snapshot ~20 s after start
        self.last_snapshot = None

    # ---------- helpers ----------
    def stat(self, agent, last=None):
        s = self.stats.setdefault(agent, {"runs": 0, "last": "idle", "ts": None})
        s["runs"] += 1
        s["ts"] = now()
        if last:
            s["last"] = last

    def log(self, agent, level, msg):
        e = {"ts": now(), "agent": agent, "level": level, "msg": msg}
        self.events.append(e)
        self.stat(agent, msg)
        self.store.event(e)

    def _median(self, d, f):
        v = [r[f] for r in list(self.history[d])[-10:] if r.get(f) is not None]
        return statistics.median(v) if v else None

    # ---------- pipeline ----------
    def ingest(self, raw):
        d = raw.get("device_id")
        if d not in self.history:
            return
        with self.lock:
            self.msgs += 1
            self.stat("Telemetry Agent", f"{C.ZONES[d]}: packet #{self.msgs} validated")
            found = self._detect(d, raw)
            clean, healed = self._heal(d, raw, found)
            rec = {"ts": raw["ts"], "zone": C.ZONES[d], **clean, "healed": healed}
            rec.update(ml.predict(clean))
            self.stat("Prediction Agent", f"{C.ZONES[d]}: health {rec['health']} · yield {rec['yield']} t/ha")
            self.history[d].append(rec)
            self.latest[d], self.pred[d] = rec, {"health": rec["health"], "yield": rec["yield"]}
            if self.auto:
                self._control(d, rec)
            self._account_water(d)
            if time.time() - self._snap_t > C.SNAPSHOT_EVERY:
                self.save_snapshot("scheduled")

    def _detect(self, d, raw):
        found, tail = [], self.rawtail[d]
        for f, (lo, hi) in RANGES.items():
            v = raw.get(f)
            if v is None:
                found.append((f, "dropout", "no value received"))
            elif not lo <= v <= hi:
                found.append((f, "out_of_range", f"{v} outside {lo}-{hi}"))
            else:
                m = self._median(d, f)
                if f in JUMP and m is not None and abs(v - m) > JUMP[f]:
                    found.append((f, "spike", f"{v} vs recent median {m:.1f}"))
        tail.append(raw)
        if len(tail) == 10:
            for f in STUCK:
                vals = [r.get(f) for r in tail]
                if None not in vals and len(set(vals)) == 1 and not any(x[0] == f for x in found):
                    found.append((f, "stuck", f"value frozen at {vals[0]} for 10 readings"))
        keys = {(f, k) for f, k, _ in found}
        for f, k, detail in found:
            if (f, k) not in self.active[d]:
                self.anomalies.append({"ts": raw["ts"], "device": d, "zone": C.ZONES[d], "field": f, "kind": k, "detail": detail})
                self.log("Anomaly Agent", "alert", f"{C.ZONES[d]}: {k.replace('_', ' ')} on {f} ({detail})")
        self.active[d] = keys
        return found

    def _heal(self, d, raw, found):
        clean, healed, h = dict(raw), [], self.health[d]
        for f, k, _ in found:
            m = self._median(d, f)
            if m is None:
                m = (RANGES[f][0] + RANGES[f][1]) / 2 if raw.get(f) is None else raw[f]
            clean[f] = round(m, 2)
            healed.append(f)
        keys = {(f, k) for f, k, _ in found}
        for f, k, _ in [x for x in found if (x[0], x[1]) not in self.seen[d]]:
            h["faults"] += 1
            h["status"] = "healing"
            diag = {"stuck": "probe wiring or corrosion", "dropout": "loose analog/I2C connection",
                    "spike": "electrical noise", "out_of_range": "ADC glitch"}[k]
            self.log("Self-Healing Agent", "warn", f"Diagnose: {f} on {C.ZONES[d]} likely {diag}. Act: used rolling median {clean[f]}"
                     + ("; reboot command sent to node" if k == "stuck" else ""))
            if k == "stuck" and self.publisher:
                self.publisher(d, {"cmd": "reboot", "ts": now()})
        self.seen[d] = keys
        h["clean"] = 0 if found else h["clean"] + 1
        if h["status"] == "healing" and h["clean"] >= 4:
            h["status"] = "healthy"
            self.log("Self-Healing Agent", "ok", f"Verify: {C.ZONES[d]} sensors reporting normal values again")
        return clean, healed

    def _free(self, d, a):
        return time.time() >= self.hold[d][a]

    def _control(self, d, r):
        self.stat("Irrigation Agent")
        a, m, t, n, rain = self.actuators[d], r["soil_moisture"], r["temperature"], r["nitrogen"], r.get("rainfall") or 0
        z, src = C.ZONES[d], "Irrigation Agent"
        if self._free(d, "irrigation_pump"):
            if not a["irrigation_pump"] and m < MOIST_ON and rain < 1:
                self.command(d, "irrigation_pump", True, f"{z}: soil moisture {m:.0f}% < {MOIST_ON}%", src)
            elif a["irrigation_pump"] and m >= MOIST_OFF:
                self.command(d, "irrigation_pump", False, f"{z}: moisture restored to {m:.0f}%", src)
        if self._free(d, "cooling_fan"):
            if not a["cooling_fan"] and t > FAN_ON:
                self.command(d, "cooling_fan", True, f"{z}: temperature {t:.1f}°C > {FAN_ON}°C", src)
            elif a["cooling_fan"] and t < FAN_OFF:
                self.command(d, "cooling_fan", False, f"{z}: temperature back to {t:.1f}°C", src)
        if self._free(d, "fertilizer_doser"):
            if not a["fertilizer_doser"] and n < N_ON:
                self.command(d, "fertilizer_doser", True, f"{z}: nitrogen {n:.1f} < {N_ON} mg/kg", src)
            elif a["fertilizer_doser"] and n >= N_OFF:
                self.command(d, "fertilizer_doser", False, f"{z}: nitrogen restored to {n:.0f}", src)

    # ---------- actuation (used by agents, dashboard buttons and the copilot) ----------
    def command(self, d, actuator, state, reason, source, seconds=0):
        with self.lock:
            if d not in self.actuators or actuator not in ACT:
                return False
            self.actuators[d][actuator] = bool(state)
            word = "ON" if state else "OFF"
            note = ""
            if source in MANUAL:
                self.hold[d][actuator] = time.time() + C.HOLD_SECONDS
                note = f" · auto paused {C.HOLD_SECONDS}s"
            self.log(source, "act", f"{ACT_LABEL[actuator]} {word} · {reason}{note}")
            if self.publisher:
                self.publisher(d, {"actuator": actuator, "state": word, "reason": reason, "ts": now()})
        if state and seconds:
            t = threading.Timer(seconds, self.command, args=(d, actuator, False, f"{seconds}s timer finished", source))
            t.daemon = True
            t.start()
        return True

    def stop_all(self, source="Operator"):
        with self.lock:
            for d in C.DEVICES:
                for a in ACT:
                    self.actuators[d][a] = False
                    self.hold[d][a] = time.time() + 300
                    if self.publisher:
                        self.publisher(d, {"actuator": a, "state": "OFF", "reason": "emergency stop", "ts": now()})
            self.log(source, "alert", "EMERGENCY STOP: all actuators OFF · auto paused 5 min")
        return True

    def resume_auto(self, d=None, actuator=None):
        with self.lock:
            for dev in ([d] if d else C.DEVICES):
                for a in ([actuator] if actuator else ACT):
                    if dev in self.hold and a in self.hold[dev]:
                        self.hold[dev][a] = 0.0
            self.auto = True
            self.log("Irrigation Agent", "ok", "Automatic control resumed" + (f" for {ACT_LABEL.get(actuator, 'all actuators')}" if actuator else ""))
        return True

    def inject(self, d, kind):
        if d not in self.history or kind not in FAULTS or not self.publisher:
            return False
        self.log("Operator", "warn", f"Fault lab: simulating '{kind}' fault on {C.ZONES[d]}")
        self.publisher(d, {"cmd": "inject", "kind": kind, "ts": now()})
        return True

    # ---------- water accounting ----------
    def _account_water(self, d):
        t = time.time()
        last, self._last_t[d] = self._last_t[d], t
        if last is None:
            return
        dt, w = min(t - last, 30), self.water[d]
        lps = C.PUMP_LPM / 60
        if self.actuators[d]["irrigation_pump"]:
            w["used"] += lps * dt
            w["run_s"] += dt
        w["baseline"] += lps * dt * C.BASELINE_DUTY          # what a fixed-timer system would have used
        if t - self._series_t > 10:
            self._series_t = t
            u, b = self.water_stats()["used_l"], self.water_stats()["baseline_l"]
            self.water_series.append({"t": now()[11:19], "used": u, "baseline": b, "saved": round(max(0, b - u), 1)})

    def water_stats(self):
        used = sum(w["used"] for w in self.water.values())
        base = sum(w["baseline"] for w in self.water.values())
        saved = max(0.0, base - used)
        return {"used_l": round(used, 1), "baseline_l": round(base, 1), "saved_l": round(saved, 1),
                "saved_pct": round(100 * saved / base, 0) if base > 0 else 0,
                "pump_minutes": round(sum(w["run_s"] for w in self.water.values()) / 60, 1),
                "assumption": f"fixed-timer irrigation running {int(C.BASELINE_DUTY * 100)}% of the time at {C.PUMP_LPM:g} L/min"}

    # ---------- snapshots ----------
    def summary(self, reason):
        zones = []
        for d in C.DEVICES:
            r = self.latest.get(d)
            if r:
                zones.append({"zone": C.ZONES[d], "health": r["health"], "yield": r["yield"], "moisture": r["soil_moisture"],
                              "temperature": r["temperature"], "humidity": r["humidity"], "ph": r["ph"],
                              "nitrogen": r["nitrogen"], "sensors": self.health[d]["status"],
                              "pump": self.actuators[d]["irrigation_pump"]})
        w = self.water_stats()
        return {"ts": now(), "reason": reason, "mode": self.mode, "messages": self.msgs, "zones": zones,
                "water": {k: w[k] for k in ("used_l", "baseline_l", "saved_l", "saved_pct")},
                "anomalies": len(self.anomalies), "auto": self.auto}

    def save_snapshot(self, reason="scheduled"):
        with self.lock:
            self._snap_t = time.time()
            s = self.summary(reason)
            s["s3_key"] = time.strftime("snapshots/%Y/%m/%d/%H%M%S.json", time.gmtime()) if (C.USE_AWS and C.S3_BUCKET) else None
            self.store.save_snapshot(s, {"summary": s, "detail": self.snapshot()}, s["s3_key"])
            self.last_snapshot = s
            self.log("Telemetry Agent", "ok", f"Farm snapshot saved ({reason}) → " + ("DynamoDB + S3" if C.USE_AWS else "memory"))
            return s

    # ---------- views ----------
    def average(self):
        L = list(self.latest.values())
        return {k: sum(r[k] for r in L) / len(L) for k in ml.FEATS} if L else {}

    def snapshot(self):
        with self.lock:
            tm = time.time()
            devs = {d: {"zone": C.ZONES[d], "latest": self.latest.get(d), "history": list(self.history[d])[-60:],
                        "health": self.health[d], "actuators": self.actuators[d],
                        "hold": {a: max(0, int(self.hold[d][a] - tm)) for a in ACT},
                        "water_l": round(self.water[d]["used"], 1), "pred": self.pred.get(d)} for d in C.DEVICES}
            return {"ts": now(), "mode": self.mode, "auto": self.auto, "messages": self.msgs, "devices": devs,
                    "water": {**self.water_stats(), "series": list(self.water_series)},
                    "snapshot_every": C.SNAPSHOT_EVERY, "last_snapshot": self.last_snapshot,
                    "events": list(self.events)[-50:][::-1], "anomalies": list(self.anomalies)[-25:][::-1],
                    "agents": [{"name": n, "desc": AGENTS[n], **self.stats[n]} for n in AGENTS]}
