"""Prediction Agent model: RandomForest that predicts crop health score (0-100) and yield (t/ha)."""
import numpy as np
from sklearn.ensemble import RandomForestRegressor

FEATS = ["soil_moisture", "temperature", "humidity", "ph", "nitrogen", "phosphorus",
         "potassium", "sunlight", "rainfall"]
# feature: (optimum, tolerance width, weight)
OPT = {"soil_moisture": (55, 35, .25), "temperature": (26, 12, .20), "humidity": (65, 40, .10),
       "ph": (6.5, 1.6, .15), "nitrogen": (70, 60, .10), "phosphorus": (35, 30, .05),
       "potassium": (150, 120, .05), "sunlight": (600, 500, .10), "rainfall": (2, 14, .02)}


def _health(X):
    tot = sum(w for _, _, w in OPT.values())
    s = sum(w * np.exp(-((X[:, i] - o) / wd) ** 2) for i, (o, wd, w) in enumerate(OPT.values()))
    return 100 * s / tot


def _train():
    rng = np.random.default_rng(7)
    lo = np.array([5, 5, 20, 4, 10, 5, 50, 0, 0])
    hi = np.array([95, 45, 100, 9, 120, 60, 250, 1000, 20])
    X = rng.uniform(lo, hi, (4000, 9))
    h = np.clip(_health(X) + rng.normal(0, 2, 4000), 0, 100)
    y = 1.5 + 7.5 * (h / 100) ** 1.5
    return RandomForestRegressor(n_estimators=60, max_depth=12, random_state=7).fit(X, np.c_[h, y])


_model = _train()


def predict(rec):
    x = np.array([[float(rec.get(f) or 0) for f in FEATS]])
    h, y = _model.predict(x)[0]
    return {"health": round(float(h), 1), "yield": round(float(y), 2)}
