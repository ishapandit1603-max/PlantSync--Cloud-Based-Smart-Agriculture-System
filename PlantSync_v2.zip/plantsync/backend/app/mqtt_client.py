"""MQTT over TLS (X.509) to AWS IoT Core."""
import json, logging
import paho.mqtt.client as mqtt
from . import config as C


def make_client(client_id):
    c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=client_id)
    c.tls_set(ca_certs=f"{C.CERT_DIR}/AmazonRootCA1.pem",
              certfile=f"{C.CERT_DIR}/device.pem.crt", keyfile=f"{C.CERT_DIR}/private.pem.key")
    c.reconnect_delay_set(1, 30)
    return c


class MqttBridge:
    """Backend side: subscribes to telemetry, publishes actuator commands."""
    def __init__(self, engine):
        self.engine = engine
        self.client = make_client("plantsync-api")

    def start(self):
        c = self.client

        def on_connect(cl, ud, flags, rc, props):
            logging.info("MQTT connected: %s", rc)
            cl.subscribe("plantsync/+/telemetry", qos=1)

        def on_message(cl, ud, msg):
            try:
                self.engine.ingest(json.loads(msg.payload))
            except Exception:
                logging.exception("bad telemetry")

        c.on_connect, c.on_message = on_connect, on_message
        c.connect_async(C.IOT_ENDPOINT, 8883, keepalive=60)
        c.loop_start()

    def publish_command(self, device, cmd):
        self.client.publish(C.TOPIC_C.format(device), json.dumps(cmd), qos=1)
