"""Persistence: events + snapshot summaries -> DynamoDB, full snapshots -> S3 (async worker, best effort)."""
import collections, json, logging, queue, threading, time
from decimal import Decimal
from . import config as C


def _plain(o):
    return float(o) if isinstance(o, Decimal) else str(o)


class Store:
    def __init__(self):
        self.on = C.USE_AWS
        self.q = queue.Queue(maxsize=500)
        self.mem = collections.deque(maxlen=50)           # snapshot summaries (also used when AWS is off)
        self.stats = {"event_writes": 0, "snapshot_writes": 0, "s3_writes": 0, "last_error": None}
        if self.on:
            import boto3
            self.ddb = boto3.resource("dynamodb", region_name=C.AWS_REGION).Table(C.DDB_TABLE)
            self.s3 = boto3.client("s3", region_name=C.AWS_REGION)
            threading.Thread(target=self._worker, daemon=True).start()

    def _put(self, kind, payload):
        if self.on:
            try:
                self.q.put_nowait((kind, payload))
            except queue.Full:
                pass

    def event(self, e):
        self._put("ev", e)

    def save_snapshot(self, summary, full, key):
        self.mem.appendleft(summary)
        self._put("snap", (summary, full, key))

    def list_snapshots(self, limit=25):
        if self.on:
            try:
                from boto3.dynamodb.conditions import Key
                r = self.ddb.query(KeyConditionExpression=Key("pk").eq("SNAPSHOT"), ScanIndexForward=False, Limit=limit)
                items = json.loads(json.dumps([i["data"] for i in r["Items"]], default=_plain))
                return {"source": "DynamoDB", "items": items, "error": None}
            except Exception as ex:
                logging.warning("snapshot query failed: %s", ex)
                return {"source": "memory", "items": list(self.mem)[:limit], "error": str(ex)[:200]}
        return {"source": "memory", "items": list(self.mem)[:limit], "error": None}

    def cloud_status(self):
        return {"aws": self.on, "region": C.AWS_REGION, "table": C.DDB_TABLE, "bucket": C.S3_BUCKET, **self.stats}

    def _worker(self):
        while True:
            kind, p = self.q.get()
            try:
                if kind == "ev":
                    item = {"pk": "EVENT", "sk": f"{p['ts']}#{p['agent']}", **p, "ttl": int(time.time()) + 7 * 86400}
                    self.ddb.put_item(Item=json.loads(json.dumps(item), parse_float=Decimal))
                    self.stats["event_writes"] += 1
                else:
                    summary, full, key = p
                    item = {"pk": "SNAPSHOT", "sk": summary["ts"], "data": summary, "ttl": int(time.time()) + 30 * 86400}
                    self.ddb.put_item(Item=json.loads(json.dumps(item), parse_float=Decimal))
                    self.stats["snapshot_writes"] += 1
                    if C.S3_BUCKET:
                        self.s3.put_object(Bucket=C.S3_BUCKET, Key=key, Body=json.dumps(full).encode(),
                                           ContentType="application/json")
                        self.stats["s3_writes"] += 1
                self.stats["last_error"] = None
            except Exception as ex:
                self.stats["last_error"] = str(ex)[:200]
                logging.warning("store error: %s", ex)
