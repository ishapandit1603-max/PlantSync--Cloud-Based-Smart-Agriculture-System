"""Virtual ESP32: replays farm_data.csv as live telemetry, reacts to actuators, and can simulate sensor faults."""
import csv, time
from . import config as C

NUM = ["soil_moisture", "temperature", "humidity", "ph", "nitrogen", "phosphorus",
       "potassium", "sunlight", "rainfall"]
FAULT_TICKS = {"stuck": 14, "spike": 2, "dropout": 4, "outofrange": 2}


def now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class VirtualESP32:
    def __init__(self, device_id, csv_path):
        self.device_id = device_id
        with open(csv_path, newline="") as f:
            self.rows = [r for r in csv.DictReader(f) if r["device_id"] == device_id]
        self.i = 0
        self.on = {"irrigation_pump": False, "fertilizer_doser": False, "cooling_fan": False}
        self.off = {"soil_moisture": 0.0, "nitrogen": 0.0, "temperature": 0.0}
        self.fault = None

    def apply_command(self, cmd):
        c = cmd.get("cmd")
        if c == "reboot":                       # self-healing: a reboot clears a stuck/faulty sensor
            self.fault = None
        elif c == "inject":                     # demo: simulate a hardware fault
            k = cmd.get("kind")
            if k in FAULT_TICKS:
                self.fault = {"kind": k, "left": FAULT_TICKS[k]}
        elif cmd.get("actuator") in self.on:
            self.on[cmd["actuator"]] = cmd.get("state") == "ON"

    def _physics(self):
        o, fast = self.off, C.DEMO_FAST
        # irrigation pump: wets the soil; otherwise the soil dries (fast in demo mode)
        o["soil_moisture"] = min(o["soil_moisture"] + 4, 40) if self.on["irrigation_pump"] else \
            (max(o["soil_moisture"] - 2.5, -40) if fast else max(o["soil_moisture"] - .5, 0))
        o["nitrogen"] = min(o["nitrogen"] + 4, 40) if self.on["fertilizer_doser"] else \
            (max(o["nitrogen"] - 1.2, -35) if fast else max(o["nitrogen"] - .1, 0))
        o["temperature"] = max(o["temperature"] - 1.5, -16) if self.on["cooling_fan"] else \
            (min(o["temperature"] + .9, 16) if fast else min(o["temperature"] + .5, 0))

    def tick(self):
        row = self.rows[self.i % len(self.rows)]
        self.i += 1
        self._physics()
        p = {"device_id": self.device_id, "field_id": row["field_id"], "ts": now()}
        for k in NUM:
            v = row.get(k, "")
            p[k] = None if v in ("", "nan") else float(v)
            if p[k] is not None and k in self.off:
                p[k] = round(p[k] + self.off[k], 2)
        f = self.fault
        if f:
            k = f["kind"]
            if k == "stuck":
                f.setdefault("val", p["soil_moisture"] if p["soil_moisture"] is not None else 40.0)
                p["soil_moisture"] = f["val"]
            elif k == "spike":
                p["temperature"] = 58.7
            elif k == "dropout":
                p["ph"] = None
            elif k == "outofrange":
                p["humidity"] = 140.0
            f["left"] -= 1
            if f["left"] <= 0:
                self.fault = None
        return p
