"""Generates farm_data.csv: 2 virtual ESP32 devices, 576 rows each (5-min steps over 2 days) with injected sensor faults."""
import csv, math, random
random.seed(42)
N = 576
cols = ["timestamp", "device_id", "field_id", "soil_moisture", "temperature", "humidity", "ph",
        "nitrogen", "phosphorus", "potassium", "sunlight", "rainfall"]
cfg = {"esp32-field-a": dict(field="A", m0=64, dm=.20, cyc=180, t0=24, n0=75, dn=.10, ph=6.4),
       "esp32-field-b": dict(field="B", m0=60, dm=.30, cyc=140, t0=25, n0=80, dn=.25, ph=6.1)}
rows = []
for dev, c in cfg.items():
    for i in range(N):
        hr = (6 + i * 5 / 60) % 24
        d = math.sin(2 * math.pi * (hr - 9) / 24)
        ph_ = i % c["cyc"]
        rain = round(random.uniform(4, 8), 1) if ph_ < 4 and i > 0 else 0.0
        m = c["m0"] - c["dm"] * ph_ + random.gauss(0, .25)
        t = c["t0"] + 7 * d + random.gauss(0, .3)
        if dev.endswith("b") and 200 <= i <= 260:
            t += 9 * min(1, (i - 200) / 12, (260 - i) / 12)          # heat wave
        h = 65 - 20 * d + random.gauss(0, 1)
        sun = max(0, 900 * math.sin(math.pi * (hr - 6) / 12)) * random.uniform(.85, 1) if 6 < hr < 18 else 0
        v = dict(soil_moisture=m, temperature=t, humidity=h, ph=c["ph"] + .15 * math.sin(i / 40) + random.gauss(0, .02),
                 nitrogen=c["n0"] - c["dn"] * (i % 288) + random.gauss(0, .4), phosphorus=35 - .01 * (i % 288) + random.gauss(0, .3),
                 potassium=150 + 8 * math.sin(i / 70) + random.gauss(0, 1), sunlight=sun, rainfall=rain)
        # ---- injected faults (for the Anomaly + Self-Healing agents) ----
        if dev.endswith("a"):
            if 60 <= i <= 75: v["soil_moisture"] = 41.3            # stuck sensor
            if i == 90: v["temperature"] = 58.7                    # impossible spike
            if 130 <= i <= 133: v["ph"] = None                     # dropout
        else:
            if i == 70: v["humidity"] = 140                        # out of range
            if i == 150: v["temperature"] = 47.0                   # spike
            if 100 <= i <= 102: v["soil_moisture"] = None          # dropout
        rows.append([f"2026-01-{1 + i // 288:02d}T{int(hr):02d}:{int(hr % 1 * 60):02d}:00Z", dev, c["field"]] +
                    [("" if v[k] is None else round(v[k], 2)) for k in cols[3:]])
with open(__file__.replace("generate_csv.py", "farm_data.csv"), "w", newline="") as f:
    w = csv.writer(f); w.writerow(cols); w.writerows(rows)
print(len(rows), "rows")
