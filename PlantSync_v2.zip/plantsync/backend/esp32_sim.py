"""Virtual ESP32 fleet: publishes CSV telemetry to AWS IoT Core and obeys actuator commands."""
import json, time
from app import config as C
from app.virtual_esp32 import VirtualESP32
from app.mqtt_client import make_client

devices = {d: VirtualESP32(d, C.CSV_PATH) for d in C.DEVICES}
c = make_client("plantsync-sim")


def on_connect(cl, ud, flags, rc, props):
    print("virtual ESP32 fleet connected:", rc, flush=True)
    for d in devices:
        cl.subscribe(C.TOPIC_C.format(d), qos=1)


def on_message(cl, ud, msg):
    devices[msg.topic.split("/")[1]].apply_command(json.loads(msg.payload))


c.on_connect, c.on_message = on_connect, on_message
c.connect_async(C.IOT_ENDPOINT, 8883, keepalive=60)
c.loop_start()
while True:
    for d, s in devices.items():
        c.publish(C.TOPIC_T.format(d), json.dumps(s.tick()), qos=1)
    time.sleep(C.SIM_INTERVAL)
