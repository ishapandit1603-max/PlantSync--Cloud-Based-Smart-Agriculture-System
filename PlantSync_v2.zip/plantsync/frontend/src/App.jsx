import { useEffect, useState } from "react";
import { LayoutDashboard, Activity, Map, Bot, TrendingUp, SlidersHorizontal, MessageCircle, Leaf, Bell, Database } from "lucide-react";
import { get } from "./api";
import { ToastHost } from "./ui";
import Dashboard from "./pages/Dashboard";
import Sensors from "./pages/Sensors";
import FieldMapPage from "./pages/FieldMapPage";
import Agents from "./pages/Agents";
import Predict from "./pages/Predict";
import Control from "./pages/Control";
import Snapshots from "./pages/Snapshots";
import Copilot from "./pages/Copilot";

const NAV = [
  ["dashboard", "Dashboard", LayoutDashboard], ["sensors", "Sensor Analytics", Activity], ["map", "Field Map", Map],
  ["agents", "AI Agents", Bot], ["predict", "Predictions & What-If", TrendingUp],
  ["control", "Actuators & Alerts", SlidersHorizontal], ["cloud", "Cloud Snapshots", Database], ["copilot", "Farm Assistant", MessageCircle],
];

export default function App() {
  const [page, setPage] = useState("dashboard");
  const [snap, setSnap] = useState(null);
  const [err, setErr] = useState(false);
  const [prefill, setPrefill] = useState("");

  const refresh = () => get("/api/snapshot").then((s) => { setSnap(s); setErr(false); }).catch(() => setErr(true));
  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 3000);
    return () => clearInterval(id);
  }, []);

  const devs = snap ? Object.values(snap.devices).filter((d) => d.latest) : [];
  const ask = (q) => { setPrefill(q); setPage("copilot"); };
  const props = { snap, devs, ask, refresh };
  const Page = { dashboard: Dashboard, sensors: Sensors, map: FieldMapPage, agents: Agents, predict: Predict, control: Control, cloud: Snapshots }[page];

  return (
    <div className="shell">
      <ToastHost />
      <aside className="side">
        <div className="brand"><span><Leaf size={22} /></span><div><b>PlantSync</b><small>Cloud farm digital twin</small></div></div>
        <nav>
          {NAV.map(([id, label, Icon]) => (
            <button key={id} className={page === id ? "on" : ""} onClick={() => setPage(id)}><Icon size={18} />{label}</button>
          ))}
        </nav>
        <div className="side-card">
          <Leaf size={20} />
          <b>Sustainable today,<br />better tomorrow</b>
          <p>{snap ? `${snap.water.saved_l} L water saved` : "Connecting…"}</p>
        </div>
      </aside>
      <main>
        <header className="top">
          <div><h1>Welcome back, Admin</h1><p className="muted">Live insights from your virtual ESP32 fleet</p></div>
          <div className="top-r">
            <span className={"chip " + (err ? "bad" : "ok")}><i />{err ? "Backend unreachable" : snap?.mode || "Connecting"}</span>
            <span className="bell"><Bell size={18} />{snap?.anomalies?.length > 0 && <em>{Math.min(snap.anomalies.length, 9)}</em>}</span>
            <span className="avatar">A</span>
          </div>
        </header>
        {!snap ? <div className="card empty">Waiting for the first telemetry packets from the cloud…</div>
          : page === "copilot" ? <Copilot {...props} prefill={prefill} clear={() => setPrefill("")} />
          : <Page key={page} {...props} />}
      </main>
    </div>
  );
}
