const BASE = import.meta.env.VITE_API_BASE || "";   // same origin in the cloud deployment
async function req(path, opt) {
  const r = await fetch(BASE + path, opt);
  let d = null;
  try { d = await r.json(); } catch { /* non-JSON body */ }
  if (!r.ok) throw new Error(d?.detail || `Server error ${r.status}`);
  return d;
}
export const get = (p) => req(p);
export const post = (p, b = {}) => req(p, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(b) });
