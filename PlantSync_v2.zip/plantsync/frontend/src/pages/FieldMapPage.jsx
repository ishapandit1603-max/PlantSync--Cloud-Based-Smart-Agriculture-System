import { Card, FieldMap, Legend, Donut, fmt } from "../ui";

export default function FieldMapPage({ devs }) {
  return (
    <div className="grid">
      <Card title="Spatial crop health" right={<Legend />} className="c-8"><FieldMap devs={devs} big /></Card>
      <div className="c-4 stack">
        {devs.map((d, i) => (
          <Card key={i} title={d.zone}>
            <div className="overview">
              <Donut value={d.pred?.health} size={120} label="health" />
              <ul className="kv">
                <li>Moisture <b>{fmt(d.latest.soil_moisture)}%</b></li><li>Temp <b>{fmt(d.latest.temperature)}°C</b></li>
                <li>pH <b>{fmt(d.latest.ph, 2)}</b></li><li>Yield <b>{fmt(d.pred?.yield, 2)} t/ha</b></li>
                <li>Sensors <b className={d.health.status}>{d.health.status}</b></li>
              </ul>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
