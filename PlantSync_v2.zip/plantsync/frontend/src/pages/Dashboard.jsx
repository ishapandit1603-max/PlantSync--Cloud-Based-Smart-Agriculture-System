import { Sprout, HeartPulse, Droplets, Wheat, Thermometer, Sun, CloudRain, Wind, OctagonX, CloudUpload } from "lucide-react";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar } from "recharts";
import { Card, Stat, Donut, FieldMap, Legend, Pipeline, WaterCard, cellsFor, series, fmt, toast, ZONE_COLORS } from "../ui";
import { post } from "../api";

export default function Dashboard({ snap, devs, refresh }) {
  const avg = (k) => devs.reduce((s, d) => s + (d.latest[k] || 0), 0) / (devs.length || 1);
  const health = devs.reduce((s, d) => s + (d.pred?.health || 0), 0) / (devs.length || 1);
  const yld = devs.reduce((s, d) => s + (d.pred?.yield || 0), 0) / (devs.length || 1);
  const cells = cellsFor(devs);
  const pct = (f) => Math.round((cells.filter(f).length / (cells.length || 1)) * 100);
  const good = pct((c) => c.h >= 70), mid = pct((c) => c.h >= 50 && c.h < 70);
  const npk = ["nitrogen", "phosphorus", "potassium"].map((k) => ({ k: k[0].toUpperCase(), a: devs[0]?.latest[k], b: devs[1]?.latest[k] }));
  const sick = devs.filter((d) => d.health.status !== "healthy").length;
  const running = devs.reduce((n, d) => n + Object.values(d.actuators).filter(Boolean).length, 0);
  const w = snap.water;

  const stopAll = () => post("/api/stop_all").then(() => { toast("Emergency stop sent: all actuators OFF", "warn"); refresh(); }).catch((e) => toast(e.message, "bad"));
  const saveSnap = () => post("/api/snapshots/now").then(() => toast("Farm snapshot saved to DynamoDB + S3")).catch((e) => toast(e.message, "bad"));

  return (
    <div className="grid">
      <section className="hero c-12">
        <div>
          <span className="hero-tag"><i />LIVE</span>
          <h2>{sick ? `${sick} zone${sick > 1 ? "s" : ""} self-healing` : "All zones healthy"}</h2>
          <p>{running} actuator{running === 1 ? "" : "s"} running · {snap.messages} MQTT packets processed · {fmt(w.saved_l, 1)} L water saved</p>
        </div>
        <div className="hero-actions">
          <button className="btn-light" onClick={stopAll}><OctagonX size={16} />Stop all pumps</button>
          <button className="btn-light" onClick={saveSnap}><CloudUpload size={16} />Save snapshot</button>
          <label className="switch light"><span>{snap.auto ? "Auto" : "Manual"}</span>
            <input type="checkbox" checked={snap.auto} onChange={(e) => post("/api/auto", { enabled: e.target.checked }).then(refresh)} /><i /></label>
        </div>
      </section>
      <div className="row4">
        <Stat icon={Sprout} label="Active zones" value={devs.length} sub={sick ? `${sick} self-healing` : "all sensors healthy"} />
        <Stat icon={HeartPulse} label="Crop health" value={fmt(health, 0)} unit="%" sub="Random Forest prediction" />
        <Stat icon={Droplets} label="Water saved" value={fmt(w.saved_l, 1)} unit=" L" sub={`${fmt(w.saved_pct, 0)}% vs fixed timer`} />
        <Stat icon={Wheat} label="Predicted yield" value={fmt(yld, 2)} unit=" t/ha" sub="season estimate" />
      </div>
      <Card title="Crop health overview" className="c-3">
        <div className="overview">
          <Donut value={health} label="overall" />
          <ul className="ov-list">
            <li><i style={{ background: "#15803d" }} />Good <b>{good}%</b></li>
            <li><i style={{ background: "#bef264" }} />Average <b>{mid}%</b></li>
            <li><i style={{ background: "#f87171" }} />Poor <b>{100 - good - mid}%</b></li>
          </ul>
        </div>
      </Card>
      <Card title="Field map" right={<Legend />} className="c-5"><FieldMap devs={devs} /></Card>
      <Card title="Environment now" className="c-4">
        <div className="env">
          <div className="env-big"><Thermometer size={34} /><strong>{fmt(avg("temperature"), 1)}°C</strong></div>
          <div className="env-grid">
            <span><Wind size={16} />Humidity <b>{fmt(avg("humidity"), 0)}%</b></span>
            <span><Sun size={16} />Sunlight <b>{fmt(avg("sunlight"), 0)} W/m²</b></span>
            <span><CloudRain size={16} />Rain <b>{fmt(avg("rainfall"), 1)} mm/h</b></span>
            <span><Droplets size={16} />pH <b>{fmt(avg("ph"), 2)}</b></span>
          </div>
        </div>
      </Card>
      <Card title="Soil moisture (%)" right={<ZoneKey devs={devs} />} className="c-5"><Lines data={series(devs, "soil_moisture")} /></Card>
      <WaterCard water={w} className="c-4" />
      <Card title="Soil nutrients (mg/kg)" className="c-3">
        <ResponsiveContainer width="100%" height={210}>
          <BarChart data={npk}><CartesianGrid vertical={false} stroke="#e5efe7" /><XAxis dataKey="k" /><YAxis width={34} /><Tooltip />
            <Bar dataKey="a" name={devs[0]?.zone} fill={ZONE_COLORS[0]} radius={[6, 6, 0, 0]} />
            <Bar dataKey="b" name={devs[1]?.zone} fill={ZONE_COLORS[1]} radius={[6, 6, 0, 0]} /></BarChart>
        </ResponsiveContainer>
      </Card>
      <Card title="Temperature (°C)" right={<ZoneKey devs={devs} />} className="c-4"><Lines data={series(devs, "temperature")} /></Card>
      <Card title="Live agent activity" className="c-8">
        <Pipeline agents={snap.agents} />
        <ul className="feed">{snap.events.filter((e) => ["alert", "warn", "act", "ok"].includes(e.level)).slice(0, 5).map((e, i) => (
          <li key={i}><i className={e.level} /><div><b>{e.agent}</b><p>{e.msg}</p></div><time>{e.ts.slice(11, 19)}</time></li>
        ))}</ul>
      </Card>
    </div>
  );
}

export const ZoneKey = ({ devs }) => (
  <span className="zkey">{devs.map((d, i) => <span key={i}><i style={{ background: ZONE_COLORS[i] }} />{d.zone}</span>)}</span>
);
export const Lines = ({ data, h = 210 }) => (
  <ResponsiveContainer width="100%" height={h}>
    <LineChart data={data}><CartesianGrid vertical={false} stroke="#e5efe7" /><XAxis dataKey="t" tick={{ fontSize: 11 }} minTickGap={40} /><YAxis width={36} domain={["auto", "auto"]} tick={{ fontSize: 11 }} /><Tooltip />
      <Line dataKey="a" stroke={ZONE_COLORS[0]} strokeWidth={2.4} dot={false} isAnimationActive={false} />
      <Line dataKey="b" stroke={ZONE_COLORS[1]} strokeWidth={2.4} dot={false} isAnimationActive={false} /></LineChart>
  </ResponsiveContainer>
);
