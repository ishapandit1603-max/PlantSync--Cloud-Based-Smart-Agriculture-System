import { Bot, ShieldCheck, Wrench, Bug } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { Card, Pipeline, ago, toast } from "../ui";
import { post } from "../api";

const FAULTS = [["stuck", "Freeze moisture probe"], ["spike", "Temperature spike"], ["dropout", "Drop pH signal"], ["outofrange", "Humidity glitch"]];

export default function Agents({ snap, ask, refresh }) {
  const kinds = Object.entries(snap.anomalies.reduce((m, a) => ({ ...m, [a.kind]: (m[a.kind] || 0) + 1 }), {})).map(([k, v]) => ({ k: k.replace("_", " "), v }));
  const inject = (device, kind, zone) => post("/api/inject", { device, kind })
    .then(() => { toast(`Fault injected on ${zone}. Watch the Anomaly and Self-Healing agents.`, "warn"); refresh(); }).catch((e) => toast(e.message, "bad"));
  return (
    <div className="grid">
      <Card title="Multi-agent pipeline" className="c-12" right={<span className="muted">every packet flows left to right</span>}><Pipeline agents={snap.agents} /></Card>
      <div className="c-12 agents">
        {snap.agents.map((a) => {
          const s = ago(a.ts);
          return (
            <div key={a.name} className={"card agent" + (s != null && s < 10 ? " live" : "")}>
              <span className="stat-ico"><Bot size={18} /></span>
              <div><b>{a.name}</b><p className="muted">{a.desc}</p><p className="sub">{a.runs} runs · {s == null ? "idle" : s + "s ago"}</p><p className="sub">{a.last}</p></div>
            </div>
          );
        })}
      </div>
      <Card title="Self-healing loop" className="c-4">
        {Object.values(snap.devices).map((d) => (
          <div key={d.zone} className="heal">
            <Wrench size={18} /><div><b>{d.zone}</b><p className="muted">{d.health.faults} faults handled</p></div>
            <span className={"pill " + d.health.status}>{d.health.status}</span>
          </div>
        ))}
        <p className="loop"><ShieldCheck size={16} />Detect → Diagnose → Act → Verify</p>
        <button className="btn" onClick={() => ask("Investigate the latest sensor anomalies and recommend what I should do.")}>Ask Llama to investigate</button>
      </Card>
      <Card title="Fault lab (demo)" className="c-4" right={<Bug size={16} />}>
        <p className="muted">Break a virtual sensor and watch the agents detect, repair and verify it.</p>
        {Object.entries(snap.devices).map(([id, d]) => (
          <div key={id} className="faultrow"><b>{d.zone}</b>
            <div>{FAULTS.map(([k, t]) => <button key={k} className="btn-ghost sm" onClick={() => inject(id, k, d.zone)}>{t}</button>)}</div></div>
        ))}
      </Card>
      <Card title="Anomalies by type" className="c-4">
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={kinds}><CartesianGrid vertical={false} stroke="#e5efe7" /><XAxis dataKey="k" tick={{ fontSize: 11 }} /><YAxis width={24} allowDecimals={false} /><Tooltip /><Bar dataKey="v" fill="#16a34a" radius={[6, 6, 0, 0]} /></BarChart>
        </ResponsiveContainer>
      </Card>
      <Card title="Agent activity timeline" className="c-6">
        <ul className="feed tall">{snap.events.map((e, i) => (
          <li key={i}><i className={e.level} /><div><b>{e.agent}</b><p>{e.msg}</p></div><time>{e.ts.slice(11, 19)}</time></li>))}</ul>
      </Card>
      <Card title="Detected anomalies" className="c-6">
        <div className="scroll"><table><thead><tr><th>Time</th><th>Zone</th><th>Sensor</th><th>Type</th></tr></thead>
          <tbody>{snap.anomalies.map((a, i) => <tr key={i}><td>{a.ts.slice(11, 19)}</td><td>{a.zone}</td><td>{a.field}</td><td><span className="pill warn">{a.kind.replace("_", " ")}</span></td></tr>)}
            {!snap.anomalies.length && <tr><td colSpan="4" className="muted">No anomalies yet. Use the Fault lab to create one.</td></tr>}</tbody></table></div>
      </Card>
    </div>
  );
}
