import { useState } from "react";
import { Droplets, Fan, FlaskConical, OctagonX, RotateCcw, Play, Square, Timer } from "lucide-react";
import { Card, WaterCard, toast } from "../ui";
import { post } from "../api";

const ACTS = [["irrigation_pump", "Irrigation pump", Droplets, "pump", "Start pump", "Stop pump"],
              ["fertilizer_doser", "Fertiliser doser", FlaskConical, "dose", "Start dosing", "Stop dosing"],
              ["cooling_fan", "Cooling fan", Fan, "fan", "Start fan", "Stop fan"]];

export default function Control({ snap, refresh }) {
  const [busy, setBusy] = useState("");
  const run = async (key, fn, okMsg, tone = "ok") => {
    setBusy(key);
    try { await fn(); toast(okMsg, tone); await refresh(); } catch (e) { toast(e.message, "bad"); }
    setBusy("");
  };
  const act = (id, d, a, state, seconds = 0) => {
    const label = ACTS.find((x) => x[0] === a)[1];
    return run(id + a + seconds, () => post("/api/actuator", { device: id, actuator: a, state, seconds }),
      `${d.zone}: ${label} ${state ? (seconds ? `running for ${seconds}s` : "started") : "stopped"}`, state ? "ok" : "warn");
  };
  const alerts = snap.events.filter((e) => ["alert", "warn", "act", "ok"].includes(e.level)).slice(0, 12);

  return (
    <div className="grid">
      <Card className="c-12 ctrl-bar">
        <div className="ctrl-row">
          <label className="switch"><span><b>{snap.auto ? "Auto mode: agents in charge" : "Manual mode: you are in charge"}</b></span>
            <input type="checkbox" checked={snap.auto} onChange={(e) => run("auto", () => post("/api/auto", { enabled: e.target.checked }), e.target.checked ? "Automatic control on" : "Manual mode on")} /><i /></label>
          <div className="ctrl-btns">
            <button className="btn-ghost" disabled={busy === "resume"} onClick={() => run("resume", () => post("/api/resume", {}), "Auto control resumed on all actuators")}><RotateCcw size={16} />Resume auto</button>
            <button className="btn-danger" disabled={busy === "stop"} onClick={() => run("stop", () => post("/api/stop_all"), "Emergency stop: everything is OFF", "warn")}><OctagonX size={16} />Emergency stop all</button>
          </div>
        </div>
        <p className="muted">Pressing any button pauses the agents for that actuator, so your decision is not instantly overridden. They take over again after the hold ends or when you press Resume auto.</p>
      </Card>

      {Object.entries(snap.devices).map(([id, d]) => (
        <Card key={id} title={d.zone} className="c-6" right={<span className={"pill " + d.health.status}>sensors {d.health.status}</span>}>
          <div className="tiles">
            {ACTS.map(([a, label, Icon, cls, startTxt, stopTxt]) => {
              const on = d.actuators[a], hold = d.hold?.[a] || 0;
              return (
                <div key={a} className={"tile " + (on ? "on " + cls : "")}>
                  <span className="tile-ico"><Icon size={26} /></span>
                  <div className="tile-main">
                    <b>{label}</b>
                    <span className={"state " + (on ? "run" : "")}>{on ? "RUNNING" : "OFF"}</span>
                    {hold > 0 ? <span className="hold">Manual hold {hold}s · <button onClick={() => run(id + a + "r", () => post("/api/resume", { device: id, actuator: a }), `${label}: auto resumed`)}>resume auto</button></span>
                      : <span className="auto">{snap.auto ? "Auto controlled" : "Manual mode"}</span>}
                  </div>
                  <div className="tile-btns">
                    <button className={on ? "btn-stop" : "btn-go"} disabled={busy.startsWith(id + a)} onClick={() => act(id, d, a, !on)}>
                      {on ? <><Square size={14} />{stopTxt}</> : <><Play size={14} />{startTxt}</>}
                    </button>
                    {a === "irrigation_pump" && !on && <button className="btn-ghost sm" onClick={() => act(id, d, a, true, 30)}><Timer size={14} />30 s</button>}
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      ))}

      <WaterCard water={snap.water} className="c-5" />
      <Card title="Alerts & actions" className="c-7">
        <ul className="feed tall">{alerts.map((e, i) => <li key={i}><i className={e.level} /><div><b>{e.agent}</b><p>{e.msg}</p></div><time>{e.ts.slice(11, 19)}</time></li>)}</ul>
      </Card>
    </div>
  );
}
