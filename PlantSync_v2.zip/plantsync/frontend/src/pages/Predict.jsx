import { useEffect, useState } from "react";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar, Legend } from "recharts";
import { Card, Donut, series, fmt, ZONE_COLORS } from "../ui";
import { Lines, ZoneKey } from "./Dashboard";
import { post } from "../api";

export default function Predict({ devs }) {
  const [d, setD] = useState({ moisture: 10, temperature: 0, nitrogen: 0, ph: 0 });
  const [res, setRes] = useState([]);
  const run = () => post("/api/whatif", d).then((r) => setRes(r.scenarios));
  useEffect(() => { run(); }, []);
  const S = (k, label, min, max, step) => (
    <label className="slider"><span>{label}<b>{d[k] > 0 ? "+" : ""}{d[k]}</b></span>
      <input type="range" min={min} max={max} step={step} value={d[k]} onChange={(e) => setD({ ...d, [k]: +e.target.value })} /></label>
  );
  return (
    <div className="grid">
      {devs.map((v, i) => (
        <Card key={i} title={v.zone} className="c-3">
          <div className="overview"><Donut value={v.pred?.health} size={120} label="health" />
            <div><p className="muted">Predicted yield</p><strong className="big">{fmt(v.pred?.yield, 2)}<small> t/ha</small></strong></div></div>
        </Card>
      ))}
      <Card title="Crop health trend (%)" right={<ZoneKey devs={devs} />} className="c-6"><Lines data={series(devs, "health")} h={180} /></Card>
      <Card title="What-if lab" className="c-4">
        <p className="muted">Adjust conditions, then let the Random Forest re-score the farm.</p>
        {S("moisture", "Soil moisture %", -30, 30, 1)}{S("temperature", "Temperature °C", -8, 10, 0.5)}
        {S("nitrogen", "Nitrogen mg/kg", -30, 40, 1)}{S("ph", "pH", -1.5, 1.5, 0.1)}
        <button className="btn" onClick={run}>Run simulation</button>
      </Card>
      <Card title="Scenario comparison" className="c-8">
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={res}><CartesianGrid vertical={false} stroke="#e5efe7" /><XAxis dataKey="name" tick={{ fontSize: 12 }} /><YAxis yAxisId="l" width={36} domain={[0, 100]} /><YAxis yAxisId="r" orientation="right" width={30} domain={[0, 10]} /><Tooltip /><Legend />
            <Bar yAxisId="l" dataKey="health" name="Health %" fill="#16a34a" radius={[6, 6, 0, 0]} />
            <Bar yAxisId="r" dataKey="yield" name="Yield t/ha" fill="#f59e0b" radius={[6, 6, 0, 0]} /></BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}
