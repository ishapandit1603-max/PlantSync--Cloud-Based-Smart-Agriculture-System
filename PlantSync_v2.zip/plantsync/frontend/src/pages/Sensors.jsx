import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell, BarChart, Bar, Legend } from "recharts";
import { Card, series, ZONE_COLORS, G } from "../ui";
import { Lines, ZoneKey } from "./Dashboard";

const METRICS = [["soil_moisture", "Soil moisture (%)"], ["temperature", "Temperature (°C)"], ["humidity", "Humidity (%)"], ["ph", "Soil pH"], ["sunlight", "Sunlight (W/m²)"], ["nitrogen", "Nitrogen (mg/kg)"]];

export default function Sensors({ devs }) {
  const L = devs.map((d) => d.latest);
  const nutri = ["nitrogen", "phosphorus", "potassium"].map((k, i) => ({ name: k, value: L.reduce((s, r) => s + r[k], 0) / L.length, c: ["#15803d", "#4ade80", "#bef264"][i] }));
  const cmp = ["soil_moisture", "temperature", "humidity"].map((k) => ({ k: k.replace("_", " "), a: L[0]?.[k], b: L[1]?.[k] }));
  return (
    <div className="grid">
      {METRICS.map(([k, t], i) => (
        <Card key={k} title={t} right={i === 0 && <ZoneKey devs={devs} />} className="c-4">
          {k === "sunlight" || k === "humidity" ? <AreaC data={series(devs, k)} /> : <Lines data={series(devs, k)} h={190} />}
        </Card>
      ))}
      <Card title="NPK nutrient share" className="c-4">
        <ResponsiveContainer width="100%" height={220}>
          <PieChart><Pie data={nutri} dataKey="value" nameKey="name" innerRadius={50} outerRadius={85} paddingAngle={3} label={(e) => e.name[0].toUpperCase()}>
            {nutri.map((n, i) => <Cell key={i} fill={n.c} />)}</Pie><Tooltip formatter={(v) => v.toFixed(1)} /></PieChart>
        </ResponsiveContainer>
      </Card>
      <Card title="Zone comparison" className="c-8">
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={cmp}><CartesianGrid vertical={false} stroke="#e5efe7" /><XAxis dataKey="k" /><YAxis width={34} /><Tooltip /><Legend />
            <Bar dataKey="a" name={devs[0]?.zone} fill={ZONE_COLORS[0]} radius={[6, 6, 0, 0]} />
            <Bar dataKey="b" name={devs[1]?.zone} fill={ZONE_COLORS[1]} radius={[6, 6, 0, 0]} /></BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}
const AreaC = ({ data }) => (
  <ResponsiveContainer width="100%" height={190}>
    <AreaChart data={data}><CartesianGrid vertical={false} stroke="#e5efe7" /><XAxis dataKey="t" tick={{ fontSize: 11 }} minTickGap={40} /><YAxis width={36} tick={{ fontSize: 11 }} /><Tooltip />
      <Area dataKey="a" stroke={ZONE_COLORS[0]} fill={G.light} fillOpacity={0.5} isAnimationActive={false} />
      <Area dataKey="b" stroke={ZONE_COLORS[1]} fill="#fde68a" fillOpacity={0.4} isAnimationActive={false} /></AreaChart>
  </ResponsiveContainer>
);
