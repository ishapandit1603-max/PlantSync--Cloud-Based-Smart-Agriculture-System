import { useEffect, useRef, useState } from "react";
import { Send, Sparkles, Leaf, Trash2, CheckCircle2, AlertTriangle, Zap } from "lucide-react";
import { get, post } from "../api";
import { toast } from "../ui";

const IDEAS = ["How is my farm doing right now?", "Should I irrigate Field A today?", "Why did a sensor fault happen and how do I fix it?",
  "How much water have we saved?", "Stop the pump in Field B", "Turn on the cooling fan in Field A"];
const HELLO = { role: "assistant", content: "Hi, I'm your PlantSync farm assistant. Ask about crop health, sensors or irrigation, or give a command like “stop the pump in Field A”.", time: new Date() };

// tiny, safe markdown: **bold** and "- " bullets
function Rich({ text }) {
  const inline = (s) => s.split(/(\*\*[^*]+\*\*)/g).map((p, i) => (p.startsWith("**") ? <b key={i}>{p.slice(2, -2)}</b> : p));
  const out = []; let list = [];
  const flush = () => { if (list.length) { out.push(<ul key={"u" + out.length}>{list.map((l, i) => <li key={i}>{inline(l)}</li>)}</ul>); list = []; } };
  text.split("\n").forEach((line) => {
    const m = line.match(/^\s*[-•*]\s+(.*)/);
    if (m) list.push(m[1]); else { flush(); if (line.trim()) out.push(<p key={out.length}>{inline(line)}</p>); }
  });
  flush();
  return <>{out}</>;
}

export default function Copilot({ prefill, clear }) {
  const [msgs, setMsgs] = useState([HELLO]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [ai, setAi] = useState(null);
  const end = useRef();
  const checkAi = () => { setAi(null); get("/api/llm/status").then(setAi).catch((e) => setAi({ ok: false, detail: e.message })); };
  useEffect(checkAi, []);
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [msgs, busy]);
  useEffect(() => { if (prefill) { send(prefill); clear(); } }, [prefill]);

  async function send(q) {
    q = q.trim();
    if (!q || busy) return;
    const history = msgs.filter((m) => m !== HELLO && !m.error).map(({ role, content }) => ({ role, content }));
    setMsgs((x) => [...x, { role: "user", content: q, time: new Date() }]); setText(""); setBusy(true);
    try {
      const r = await post("/api/chat", { message: q, history });
      setMsgs((x) => [...x, { role: "assistant", content: r.reply, sources: r.sources, actions: r.actions, model: r.model, notice: r.error, time: new Date() }]);
      if (r.actions?.length) toast("Command executed on the farm");
    } catch (e) {
      setMsgs((x) => [...x, { role: "assistant", error: true, content: `The server returned an error: ${e.message}`, time: new Date() }]);
    }
    setBusy(false);
  }
  const tm = (d) => d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  return (
    <div className="card chat2">
      <div className="chat2-head">
        <div className="chat2-title"><span className="avatar-ai"><Leaf size={18} /></span><div><b>Farm Assistant</b><small>Llama via Groq · live farm data</small></div></div>
        <div className="chat2-tools">
          <button className={"ai-chip " + (ai == null ? "wait" : ai.ok ? "ok" : "bad")} onClick={checkAi} title={ai?.detail}>
            {ai == null ? "Checking AI…" : ai.ok ? `AI online · ${ai.model}` : "AI offline · tap to retest"}</button>
          <button className="icon-btn" onClick={() => setMsgs([HELLO])} aria-label="Clear chat"><Trash2 size={16} /></button>
        </div>
      </div>
      {ai && !ai.ok && <div className="notice"><AlertTriangle size={16} /><span>{ai.detail}{ai.raw ? <em> ({ai.raw})</em> : null}</span></div>}
      <div className="chat2-log">
        {msgs.map((m, i) => (
          <div key={i} className={"msg " + m.role + (m.error ? " err" : "")}>
            {m.role === "assistant" && <span className="avatar-ai sm"><Leaf size={14} /></span>}
            <div className="msg-body">
              <div className="msg-bubble"><Rich text={m.content} /></div>
              {m.actions?.length > 0 && <div className="chips">{m.actions.map((a, j) => <span key={j} className="chip-act"><Zap size={12} />{a}</span>)}</div>}
              {m.notice && <div className="chip-warn"><AlertTriangle size={13} />{m.notice.detail}</div>}
              {m.sources?.length > 0 && <div className="chips">{m.sources.map((s) => <span key={s} className="chip-src">{s}</span>)}</div>}
              <small className="msg-time">{m.time && tm(m.time)}{m.model ? ` · ${m.model}` : ""}</small>
            </div>
          </div>))}
        {busy && <div className="msg assistant"><span className="avatar-ai sm"><Leaf size={14} /></span><div className="msg-bubble typing"><i /><i /><i /></div></div>}
        <div ref={end} />
      </div>
      <div className="ideas">{IDEAS.map((q) => <button key={q} onClick={() => send(q)}><Sparkles size={13} />{q}</button>)}</div>
      <div className="composer">
        <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send(text)} placeholder="Ask your farm anything…" aria-label="Message" />
        <button className="btn" disabled={busy || !text.trim()} onClick={() => send(text)} aria-label="Send"><Send size={16} /></button>
      </div>
    </div>
  );
}
