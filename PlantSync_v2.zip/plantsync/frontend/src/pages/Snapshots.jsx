import { useEffect, useState } from "react";
import { Database, HardDrive, CloudUpload, Radio, RefreshCw } from "lucide-react";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { Card, fmt, toast, ZONE_COLORS } from "../ui";
import { get, post } from "../api";

export default function Snapshots({ snap }) {
  const [data, setData] = useState(null);
  const [busy, setBusy] = useState(false);
  const load = () => get("/api/snapshots").then(setData).catch((e) => toast(e.message, "bad"));
  useEffect(() => { load(); const id = setInterval(load, 8000); return () => clearInterval(id); }, []);
  const saveNow = async () => {
    setBusy(true);
    try { await post("/api/snapshots/now"); toast("Snapshot saved. Refreshing list…"); setTimeout(load, 1500); } catch (e) { toast(e.message, "bad"); }
    setBusy(false);
  };
  if (!data) return <div className="card empty">Loading cloud snapshots…</div>;
  const items = data.items, c = data.cloud;
  const chart = [...items].reverse().map((s) => ({ t: s.ts.slice(11, 19), a: s.zones?.[0]?.health, b: s.zones?.[1]?.health }));
  return (
    <div className="grid">
      <div className="row4">
        <div className="card stat"><span className="stat-ico"><Database size={22} /></span><div><p className="muted">DynamoDB</p><strong>{c.snapshot_writes}<small> snapshots</small></strong><p className="sub">{c.table} · {c.event_writes} events</p></div></div>
        <div className="card stat"><span className="stat-ico"><HardDrive size={22} /></span><div><p className="muted">S3 bucket</p><strong>{c.s3_writes}<small> files</small></strong><p className="sub">{c.bucket || "not set"}</p></div></div>
        <div className="card stat"><span className="stat-ico"><Radio size={22} /></span><div><p className="muted">Region</p><strong className="sm">{c.region}</strong><p className="sub">{c.aws ? "AWS storage ON" : "memory only (demo)"}</p></div></div>
        <div className="card stat"><span className="stat-ico"><RefreshCw size={22} /></span><div><p className="muted">Auto snapshot</p><strong>{data.every}<small> s</small></strong><p className="sub">read from: {data.source}</p></div></div>
      </div>
      {(data.error || c.last_error) && <div className="card warnbox c-12">Cloud storage notice: {data.error || c.last_error}. Check the EC2 IAM role and the .env values for table, bucket and region.</div>}
      <Card title="Crop health at each snapshot (%)" className="c-7" right={<button className="btn" disabled={busy} onClick={saveNow}><CloudUpload size={15} /> Save snapshot now</button>}>
        <ResponsiveContainer width="100%" height={230}>
          <LineChart data={chart}><CartesianGrid vertical={false} stroke="#e5efe7" /><XAxis dataKey="t" tick={{ fontSize: 11 }} /><YAxis width={34} domain={[0, 100]} /><Tooltip />
            <Line dataKey="a" name="Field A" stroke={ZONE_COLORS[0]} strokeWidth={2.4} /><Line dataKey="b" name="Field B" stroke={ZONE_COLORS[1]} strokeWidth={2.4} /></LineChart>
        </ResponsiveContainer>
      </Card>
      <Card title="Where your data lives" className="c-5">
        <ul className="where">
          <li><b>DynamoDB · TEL#…</b><span>every sensor packet (via IoT Rule + Lambda), kept 7 days</span></li>
          <li><b>DynamoDB · EVENT</b><span>agent decisions, alerts and actuations</span></li>
          <li><b>DynamoDB · SNAPSHOT</b><span>farm summary table shown here, kept 30 days</span></li>
          <li><b>S3 · snapshots/</b><span>full farm state as JSON for each snapshot</span></li>
        </ul>
      </Card>
      <Card title="Saved farm snapshots" className="c-12">
        <div className="scroll"><table>
          <thead><tr><th>Saved at (UTC)</th><th>Why</th><th>Field A</th><th>Field B</th><th>Water saved</th><th>Packets</th><th>S3 file</th></tr></thead>
          <tbody>{items.map((s) => (
            <tr key={s.ts}>
              <td>{s.ts.replace("T", " ").replace("Z", "")}</td><td><span className="pill">{s.reason}</span></td>
              {[0, 1].map((i) => <td key={i}>{s.zones?.[i] ? `${fmt(s.zones[i].health, 0)}% health · ${fmt(s.zones[i].moisture, 0)}% moisture` : "–"}</td>)}
              <td>{fmt(s.water?.saved_l, 1)} L ({fmt(s.water?.saved_pct, 0)}%)</td><td>{s.messages}</td><td className="mono">{s.s3_key ? s.s3_key.split("/").slice(-1)[0] : "–"}</td>
            </tr>))}
            {!items.length && <tr><td colSpan="7" className="muted">The first snapshot is saved about 20 seconds after start. Press “Save snapshot now”.</td></tr>}
          </tbody></table></div>
      </Card>
    </div>
  );
}
