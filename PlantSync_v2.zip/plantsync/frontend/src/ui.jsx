import { useEffect, useState } from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";

export const G = { dark: "#15803d", main: "#22c55e", light: "#86efac", pale: "#dcfce7", amber: "#f59e0b", red: "#ef4444", blue: "#38bdf8", ink: "#14532d" };
export const fmt = (v, d = 1) => (v == null || isNaN(v) ? "–" : Number(v).toFixed(d));
export const hhmm = (ts) => (ts ? ts.slice(11, 19) : "");
export const ZONE_COLORS = ["#16a34a", "#f59e0b"];

export const Card = ({ title, right, children, className = "" }) => (
  <section className={"card " + className}>
    {(title || right) && <header><h3>{title}</h3>{right}</header>}
    {children}
  </section>
);

export const Stat = ({ icon: Icon, label, value, unit, sub }) => (
  <div className="card stat">
    <span className="stat-ico"><Icon size={22} /></span>
    <div>
      <p className="muted">{label}</p>
      <strong>{value}<small>{unit}</small></strong>
      {sub && <p className="sub">{sub}</p>}
    </div>
  </div>
);

export function Donut({ value, size = 160, color = G.main, label }) {
  const v = Math.max(0, Math.min(100, value || 0));
  return (
    <div className="donut" style={{ width: size, height: size }}>
      <PieChart width={size} height={size}>
        <Pie data={[{ v }, { v: 100 - v }]} dataKey="v" innerRadius={size * 0.34} outerRadius={size * 0.46} startAngle={90} endAngle={-270} stroke="none">
          <Cell fill={color} /><Cell fill="#e8f3ea" />
        </Pie>
      </PieChart>
      <div className="donut-c"><strong>{Math.round(v)}%</strong>{label && <span>{label}</span>}</div>
    </div>
  );
}

// merge both zones' history into one array for multi-line charts
export function series(devs, key) {
  const [a, b] = devs.map((d) => d.history || []);
  const n = Math.max(a?.length || 0, b?.length || 0);
  return Array.from({ length: n }, (_, i) => ({ t: hhmm((a?.[i] || b?.[i]).ts), a: a?.[i]?.[key], b: b?.[i]?.[key] }));
}

// field grid: 2 fields x (6x4) cells, shaded by predicted crop health
export function cellsFor(devs) {
  return devs.flatMap((d, z) => Array.from({ length: 24 }, (_, i) => {
    const base = d.pred?.health ?? 0;
    const h = Math.max(0, Math.min(100, base + Math.sin((i + 1) * 12.9898 + z * 4) * 9));
    return { z, i, h, hit: (d.latest?.healed || []).length > 0 && i % 7 === 0 };
  }));
}
export const cellColor = (h) => (h >= 80 ? "#15803d" : h >= 65 ? "#4ade80" : h >= 50 ? "#bef264" : h >= 35 ? "#fbbf24" : "#f87171");

export function FieldMap({ devs, big }) {
  const cells = cellsFor(devs);
  return (
    <div className={"fieldmap" + (big ? " big" : "")}>
      {devs.map((d, z) => (
        <div key={z} className="plot">
          <div className="plot-grid">
            {cells.filter((c) => c.z === z).map((c) => (
              <i key={c.i} title={`${d.zone}: ${Math.round(c.h)}% health`} style={{ background: cellColor(c.h), outline: c.hit ? "2px solid #ef4444" : "none" }} />
            ))}
          </div>
          <span className="plot-label">{d.zone}</span>
          <span className="pin" style={{ left: "46%", top: "42%" }} />
        </div>
      ))}
    </div>
  );
}
export const Legend = () => (
  <div className="legend">{[["#15803d", "Excellent"], ["#4ade80", "Good"], ["#bef264", "Fair"], ["#fbbf24", "Stressed"], ["#f87171", "Critical"]].map(([c, t]) => <span key={t}><i style={{ background: c }} />{t}</span>)}</div>
);

// ---------- toasts ----------
let pushToast = () => {};
export const toast = (msg, tone = "ok") => pushToast(msg, tone);
export function ToastHost() {
  const [items, setItems] = useState([]);
  useEffect(() => {
    pushToast = (msg, tone) => {
      const id = Math.random();
      setItems((x) => [...x.slice(-3), { id, msg, tone }]);
      setTimeout(() => setItems((x) => x.filter((i) => i.id !== id)), 3600);
    };
  }, []);
  return <div className="toasts" role="status" aria-live="polite">{items.map((t) => <div key={t.id} className={"toast " + t.tone}>{t.msg}</div>)}</div>;
}

export const ago = (ts) => (ts ? Math.max(0, Math.round((Date.now() - Date.parse(ts)) / 1000)) : null);

// ---------- agent pipeline strip ----------
const PIPE = ["Telemetry Agent", "Anomaly Agent", "Self-Healing Agent", "Irrigation Agent", "Prediction Agent"];
export function Pipeline({ agents }) {
  const by = Object.fromEntries(agents.map((a) => [a.name, a]));
  return (
    <div className="pipe">
      {PIPE.map((n) => {
        const s = ago(by[n]?.ts);
        return (
          <div key={n} className={"pipe-n" + (s != null && s < 10 ? " live" : "")}>
            <i /><b>{n.replace(" Agent", "")}</b><small>{s == null ? "idle" : s + "s ago"}</small>
          </div>
        );
      })}
    </div>
  );
}

// ---------- water saved card ----------
export function WaterCard({ water, className = "" }) {
  return (
    <Card title="Water saved" className={className} right={<span className="pill">{fmt(water.saved_pct, 0)}% less</span>}>
      <div className="water-top">
        <div className="drop"><span /></div>
        <div><strong className="big">{fmt(water.saved_l, 1)}<small> L saved</small></strong>
          <p className="sub">vs fixed-timer irrigation</p></div>
      </div>
      <ResponsiveContainer width="100%" height={120}>
        <AreaChart data={water.series}>
          <CartesianGrid vertical={false} stroke="#e5efe7" /><XAxis dataKey="t" hide /><YAxis width={30} tick={{ fontSize: 10 }} /><Tooltip />
          <Area dataKey="baseline" name="Fixed timer (L)" stroke="#94a3b8" fill="#e2e8f0" fillOpacity={0.6} isAnimationActive={false} />
          <Area dataKey="used" name="PlantSync (L)" stroke={G.main} fill={G.light} fillOpacity={0.7} isAnimationActive={false} />
        </AreaChart>
      </ResponsiveContainer>
      <div className="mini3"><span>Used<b>{fmt(water.used_l, 1)} L</b></span><span>Timer would use<b>{fmt(water.baseline_l, 1)} L</b></span><span>Pump time<b>{fmt(water.pump_minutes, 1)} min</b></span></div>
      <p className="note">Estimate vs. {water.assumption}.</p>
    </Card>
  );
}
