# PlantSync: cloud smart-agriculture digital twin

Virtual ESP32 sensors → **MQTT** → **AWS IoT Core** → Lambda → DynamoDB / S3 → **FastAPI multi-agent backend (Random Forest + Llama via Groq)** → **React + Recharts** dashboard. Everything runs on one free-tier EC2 server and opens at a public URL (no localhost).

```
plantsync/
├─ backend/            FastAPI, agents, ML, virtual ESP32, CSV data
│  ├─ app/engine.py    orchestrator + Telemetry / Anomaly / Self-Healing / Irrigation / Prediction agents
│  ├─ app/ml.py        RandomForest (crop health + yield)
│  ├─ app/knowledge.py Knowledge Agent (agronomy retrieval)
│  ├─ app/copilot.py   Farm Copilot (Groq Llama + tool calling)
│  ├─ esp32_sim.py     virtual ESP32 fleet → AWS IoT Core
│  └─ data/farm_data.csv (+ generate_csv.py)  sensor CSV with injected faults
├─ frontend/           React + Vite + Recharts (7 dashboard pages)
├─ deploy/             setup_aws.sh, ec2_user_data.sh, iot_policy.json, lambda/handler.py
├─ Dockerfile, docker-compose.yml, .env.example
```


## v2 changes
* **Farm Assistant**: auto-selects a live Groq model (`GROQ_MODEL=auto`), runs commands like "stop the pump in Field A" locally, shows the real error reason, and has an AI status badge.
* **Buttons that work**: manual Start/Stop (plus a 30 s pump run), Emergency stop, Resume auto. A manual action pauses the agents for `HOLD_SECONDS`.
* **Water saved** estimate vs a fixed-timer irrigation baseline, on the Dashboard and Actuators pages.
* **Cloud Snapshots** page: farm snapshots saved to DynamoDB (`pk = SNAPSHOT`) and S3 every `SNAPSHOT_EVERY` seconds, or on demand.
* **Fault lab** on the AI Agents page, plus `DEMO_FAST` so automatic switching is visible within about a minute.

## Agents (7 + orchestrator)
Telemetry · Anomaly Detection · Self-Healing (detect → diagnose → act → verify) · Irrigation/Control (pump, fertiliser, fan) · Prediction (Random Forest) · Knowledge · Farm Copilot (Llama, can switch actuators by tool calling).

## Deploy on AWS free tier (about 30 minutes)

### 0. Prerequisites
* AWS account, Groq API key (console.groq.com), GitHub account (optional but easiest), VS Code.
* Set a **billing alarm** first: Billing → Budgets → Zero-spend budget.
* Region used below: `ap-south-1` (Mumbai). Change with `AWS_REGION` if you like.

### 1. Push the project to GitHub (from VS Code)
Unzip, open the folder in VS Code, then `git init`, commit, and push to a **private** repo. `.env` and `certs/` are git-ignored.

### 2. Create the AWS services (CloudShell, nothing to install)
1. AWS Console → click the **CloudShell** icon (top bar).
2. Upload the `deploy` folder (Actions → Upload file, or `git clone` your repo), `cd deploy`.
3. `bash setup_aws.sh`
   Creates DynamoDB table, S3 bucket, IoT Core thing + certificate + policy, Lambda `plantsync-ingest` + IoT Rule, and the EC2 IAM role.
4. Copy the printed `IOT_ENDPOINT` and `S3_BUCKET`. Download `certs/device.pem.crt`, `certs/private.pem.key`, `certs/AmazonRootCA1.pem` (Actions → Download file).

### 3. Launch the server (EC2)
1. EC2 → Launch instance: **Amazon Linux 2023**, instance type marked **Free tier eligible** (t2.micro/t3.micro), create a key pair (.pem).
2. Network: allow **SSH (22) from My IP** and **HTTP (80) from Anywhere**.
3. Advanced details → **IAM instance profile = PlantSyncEC2Profile**; **User data** = contents of `deploy/ec2_user_data.sh`.
4. Launch, wait 3 minutes, note the **Public IPv4 address**.

### 4. Put the code on the server (VS Code Remote-SSH)
1. VS Code extension **Remote - SSH** → connect to `ec2-user@<public-ip>` with your key.
2. In the remote terminal: `git clone <your-repo-url> plantsync && cd plantsync` (or drag the folder into the remote Explorer).
3. Drag your 3 cert files into `plantsync/certs/`.
4. `cp .env.example .env`, edit it: paste `GROQ_API_KEY`, `IOT_ENDPOINT`, `S3_BUCKET`.

### 5. Run
```bash
docker compose up -d --build     # first build takes ~5-8 min on a free-tier box
docker compose logs -f           # "MQTT connected: Success" and "virtual ESP32 fleet connected"
```
Open **http://\<EC2-public-IP\>** in a browser. Within ~10 seconds the dashboard is live.
Optional: attach an Elastic IP (free while attached) so the address never changes.

### 6. Verify the cloud pipeline
* IoT Core → **MQTT test client** → subscribe to `plantsync/#` to see live telemetry and commands.
* DynamoDB → table `PlantSyncState` → Explore items: `TEL#...` (Lambda) and `EVENT` (agents).
* S3 bucket → `snapshots/` (every 5 minutes). CloudWatch → Log groups → `/aws/lambda/plantsync-ingest`.

## What to try
* Wait for Field A's stuck moisture probe and Field B's spikes (injected in the CSV): see them in **AI Agents**, healed automatically.
* **Actuators & Alerts**: pump/fan/doser switch on by themselves when moisture < 30%, temp > 34°C or N < 45; toggle manually too.
* **Predictions & What-If**: move the sliders and re-score the farm.
* **Farm Assistant**: "Turn on the cooling fan in Field B" (Llama calls the actuator tool).

## Free-tier cost control (important)
* Each reading costs several IoT messages (publish plus each delivery). At `SIM_INTERVAL=5` that is roughly 100k billed messages per day, so **run the simulator only for demos**: `docker compose stop sim` / `start sim`.
* For 24/7 operation use `SIM_INTERVAL=30` in `.env`. Free-tier terms change (new accounts may get credits instead), so confirm on the AWS Free Tier page.
* DynamoDB uses 5 RCU/WCU and 7-day TTL; S3 snapshots are tiny. Stop the EC2 instance when you don't need it.

## Run without AWS (optional preview)
Set `MQTT_ENABLED=false` in `.env`: the backend runs the virtual ESP32s internally (no certs, no IoT Core) and the same dashboard works. For frontend work in VS Code: `cd frontend && npm install && npm run dev` with `VITE_API_BASE=http://<EC2-IP>` in `frontend/.env`.

## Regenerate / replace the sensor data
`python backend/data/generate_csv.py`, or drop in your own CSV with columns: `timestamp,device_id,field_id,soil_moisture,temperature,humidity,ph,nitrogen,phosphorus,potassium,sunlight,rainfall`.

## Tear down
Terminate EC2; delete the DynamoDB table, S3 bucket, IoT rule/thing/certificate/policy, Lambda and the two IAM roles.

## Troubleshooting
* Dashboard says "Backend unreachable": security group missing HTTP 80, or `docker compose ps` shows api down.
* No data: check `docker compose logs sim`. Wrong `IOT_ENDPOINT` or missing certs are the usual cause.
* Build killed: swap not active (`free -h`); rerun the user-data swap commands.
* Chat shows a status summary only: `GROQ_API_KEY` empty or invalid.
